"""Renders the animated Windows Terminal background for the "blossom" theme.

The status line can only paint its own rows, so a dark pink behind the WHOLE
window means Windows Terminal's per-profile `backgroundImage`. This generates
it; `sl-blossom-wt.py` points the profile at it.

WHAT IS IN IT. A vertical dusk of eight plum bands fading into the flat theme
background (BP.BG, palette index 7), one sakura limb system reaching in from
the TOP RIGHT, and petals. Thirty-four blossom sites on the limbs each run
their own bud -> swell -> half -> full -> shed -> bare cycle; a shed blossom
drops its petals one by one, and they drift down and fade into the dusk.
Eighteen more petals fall all the time, independent of any blossom.

THE BOTTOM BAND IS SACRED. Rows 126-179 are pure index 7 in every frame, and
rows 72-125 only ever hold index 7 or a fading petal (10, 12, 14). The flower
bed belongs to the status line panel, which is transparent between its flowers:
whatever the GIF draws down there shows THROUGH the panel, at whatever height
WT's "fill" stretch happens to put it. Keeping the band flat BG means the panel
always sits on exactly the colour it was designed against, at any aspect ratio
(`assert_band_invariant` checks it on every build).

DIM ON PURPOSE. Every art colour has relative luminance <= 0.105, so Claude
Code's text (#FBE4F0) keeps >= 5.6:1 over any pixel of the image. The petals
here read as far away; the vivid flowers are the panel's.

SEAMLESS LOOPING. A GIF restarts hard, so every motion and colour swap here
completes a whole number of periods over FRAMES (192): site phases are integer
offsets into the loop, flutter and wobble periods (12, 48 frames) divide 192,
and falling petals key off (f - birth) % FRAMES. `verify_seamless` checks
frame(0) == frame(FRAMES); `frame` deliberately does not reduce f itself.

Deliberately low resolution, like meadowsky: 320 px stretched over a ~1900 px
window is ~6 screen pixels per art pixel, which is what reads as pixel art.
Opaque frames on one 32-entry global palette, disposal 1 (inside the 0-3 the
XAML decoder accepts). Deterministic: noise() is a hash, never `random`, so two
builds are byte-identical.

THE SKY VARIANT ("blossomsky"). With blossompal.use("sky") (or
build(path, "sky")) the same limbs, sites, blossom cycle, shed and ambient
petals are drawn, index for index, over a pastel morning sky instead of the
dusk: GIF_GRADIENT's 14 bands over rows 0-125 (zenith BG_TOP down to BG, the
last row of each band checkerboarded into the next), six static white clouds
with a 1-px highlight rim and a warm underside, and thin haze streaks low in
the sky (rows 96-123). Indices 0-18 keep their meaning (7 is BG, 8-18 the art,
in the sky's light colours); the 13 extra slots hold the sky: gradient bands
7-12 at 19-24 (SKY_BAND_SLOT), the clouds at 25-28 and the haze at 29-31, so
the sky fills all 32 entries. Rows 126-179 stay pure BG in every frame, exactly
as for pink (the cohesion rule), and R3 flips: every art colour is LIGHT
(BP.GIF_ART_LUM), so the navy scheme foreground keeps >= 4.6:1 over the art.
The clouds are static: a seamless drift would have to cross 320 px in 23 s.
Pink is untouched by all of this: same palette, same frames, same bytes.

    python3 blossomgif.py [outdir=/tmp/blossom-preview] [--variant pink|sky]
"""

import contextlib
import math
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import blossompal as BP
import gifwriter

# Bump when the ART changes: WT caches background images by URI, so the new
# art has to arrive under a new file name or it will never be shown.
# 2: the dark pink palette (BG #6B0F3A) and the all-BARK_DK 1-px limb tip.
REVISION = 2
FILE = "blossom-bg-v%d.gif" % REVISION
# Per variant (blossompal.variant()). The sky counts its own revisions; its
# file stem is its theme name, so blossom.is_opaque() can tell the two apart.
REVISIONS = {"pink": REVISION, "sky": 1}


def file_name(variant=None):
    """GIF file name of a variant (default: the active one):
    blossom-bg-v2.gif (== FILE) or blossomsky-bg-v1.gif."""
    v = variant or BP.variant()
    return "%s-bg-v%d.gif" % (BP.theme_name(v), REVISIONS[v])


@contextlib.contextmanager
def variant(name):
    """Draw as variant `name` ("pink" / "sky" or a theme name) inside the
    block; the previous blossompal variant always comes back."""
    prev = BP.use(name)
    try:
        yield
    finally:
        BP.use(prev)

WIDTH, HEIGHT = 320, 180       # 16:9, a 1/6 scale of 1920x1080
FRAMES = 192
DELAY_CS = 12                  # 8.33 fps; the loop is exactly 23.04 s
MAX_BYTES = 1500000

# Fixed-point loop position: a site's phase is an integer offset in 1/16-frame
# units, so u is exact and frame(FRAMES) reproduces frame(0) bit for bit (a
# float `(f / 192 + phi) % 1` can land a hair either side of a stage edge).
SUB = 16
LOOP = FRAMES * SUB

MAIN_THICK = (5, 2)            # px at the trunk end, px at the tip
SECOND_THICK = (3, 1)

M64 = 0xFFFFFFFFFFFFFFFF


def noise(*key):
    h = 0x9E3779B97F4A7C15
    for k in key:
        h = (h + (int(k) & M64) + 0x9E3779B97F4A7C15) & M64
        h = ((h ^ (h >> 30)) * 0xBF58476D1CE4E5B9) & M64
        h = ((h ^ (h >> 27)) * 0x94D049BB133111EB) & M64
        h ^= h >> 31
    return (h & 0xFFFFFFFF) / 4294967296.0


# --- palette (indices are part of the art) -----------------------------------

I_BG = 7                       # BANDS[7] == BP.BG: the flat bottom 60 %
I_BARK_DK, I_BARK, I_BARK_HI = 8, 9, 10
I_BUD = 11
I_PETAL_SH, I_PETAL_MID, I_PETAL_LT, I_PETAL_MAX = 12, 13, 14, 15
I_CENTRE = 16
I_LEAF_DK, I_LEAF = 17, 18
PALETTE_LEN = 32
ART = range(8, 19)
ART_LUM_MAX = 0.105            # pink's bound; the active one is BP.GIF_ART_LUM
TEXT_MIN = 4.5                 # scheme foreground over ANY palette entry

# Sky only (BP.GIF_GRADIENT non-empty). Band k of the 14 sits in slot
# SKY_BAND_SLOT[k]: 0-6 as in pink, 7-12 in the spare slots, the last (BG)
# in I_BG, so every check keyed on index 7 holds for both variants.
SKY_BANDS = 14
SKY_BAND_SLOT = (0, 1, 2, 3, 4, 5, 6, 19, 20, 21, 22, 23, 24, I_BG)
I_CLOUD_HI, I_CLOUD, I_CLOUD_SH, I_CLOUD_WARM = 25, 26, 27, 28
I_HAZE = (29, 30, 31)          # cool -> warm, top streaks -> bottom streaks
# Clouds: (centre x, flat base row, width) in art px. Every base <= 118, so a
# cloud never reaches the bed band; the limb is drawn in front of them.
CLOUDS = ((52, 44, 64), (150, 24, 46), (238, 70, 58),
          (112, 90, 40), (20, 108, 34), (284, 112, 34))
HAZE_ROWS = (96, 123)          # haze streaks live in these rows (inclusive)
# What the limb may never leave below DUSK_ROW: wood, buds, blossoms, leaves.
# (Pink's DUSK_OK is the stricter "BG or a fading petal"; the sky's dusk rows
# also hold gradient bands, clouds and haze.)
WOOD = frozenset((I_BARK_DK, I_BARK, I_BUD, I_PETAL_MID, I_PETAL_MAX,
                  I_CENTRE, I_LEAF_DK, I_LEAF))

# The only indices a petal may leave in the dusk rows 72-125.
DUSK_ROW, LOW_ROW = 72, 126
DUSK_OK = frozenset((I_BG, I_BARK_HI, I_PETAL_SH, I_PETAL_LT))
SINGLE_ROW = 100               # petals shrink to one pixel below this row
DRIFT = 8                      # shed petals drift 1 px right per DRIFT frames


def _lum(rgb):
    def lin(v):
        v /= 255.0
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(v) for v in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _contrast(a, b):
    la, lb = sorted((_lum(a), _lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def is_sky():
    return bool(BP.GIF_GRADIENT)


def palette():
    """The one global colour table, 32 entries. Pad slots are BG, never black.
    Pink: 8 dusk bands, the art, pads. Sky: the 14-band gradient, the same art
    indices in light colours, clouds and haze (no pads left)."""
    art = (BP.BARK_DK, BP.BARK, BP.BARK_HI, BP.BUD_FAR, BP.PETAL_SH,
           BP.PETAL_MID, BP.PETAL_LT, BP.PETAL_MAX, BP.CENTRE_FAR,
           BP.LEAF_DK, BP.LEAF_FAR)
    if is_sky():
        pal = _sky_palette(art)
    else:
        pal = [BP.hx(c) for c in BP.BANDS] + [BP.hx(c) for c in art]
        pal += [BP.hx(BP.BG)] * (PALETTE_LEN - len(pal))
    assert len(pal) == PALETTE_LEN
    assert BP.BANDS[I_BG] == BP.BG, "band 7 must be the theme background"
    assert pal[I_BG] == BP.hx(BP.BG) == BP.hx(BP.SCHEME["background"]), "R1"
    lo, hi = BP.GIF_ART_LUM
    lums = [_lum(pal[i]) for i in ART]
    assert max(lums) <= hi, "GIF art too bright (lum %.4f)" % max(lums)
    assert min(lums) >= lo, "GIF art too dark (lum %.4f)" % min(lums)
    fg = BP.hx(BP.SCHEME["foreground"])
    worst = min(_contrast(fg, c) for c in pal)
    assert worst >= TEXT_MIN, "scheme text only %.2f:1 over the GIF" % worst
    return pal


def _sky_palette(art):
    grad = BP.GIF_GRADIENT
    assert len(grad) == SKY_BANDS, "sky gradient needs %d bands" % SKY_BANDS
    assert grad[0] == BP.BG_TOP and grad[-1] == BP.BG, "gradient ends"
    assert len(BP.CLOUD) == 4 and len(BP.HAZE) == len(I_HAZE)
    pal = [None] * PALETTE_LEN
    slots = list(zip(SKY_BAND_SLOT, grad)) + list(zip(ART, art))
    slots += list(zip((I_CLOUD_HI, I_CLOUD, I_CLOUD_SH, I_CLOUD_WARM), BP.CLOUD))
    slots += list(zip(I_HAZE, BP.HAZE))
    for i, c in slots:
        assert pal[i] is None, "slot %d used twice" % i
        pal[i] = BP.hx(c)
    assert None not in pal, "sky palette has an empty slot"
    return pal


# --- sprites ------------------------------------------------------------------
# Grids are centred on the blossom site: cell (rows // 2, cols // 2) sits on it.
# Keys: s swell, m mid petal, l light petal, b brightest petal, c centre.

SPRITE_KEYS = {"s": I_PETAL_SH, "m": I_PETAL_MID, "l": I_PETAL_LT,
               "b": I_PETAL_MAX, "c": I_CENTRE}

SWELL = [".s.", "sms"]
HALF = [".l.", "lcl", ".m."]
FULL = [".l.l.", "lbmbl", ".mcm.", "lbmbl", "..l.."]

# The five l-petals that detach during SHED, in order (row, col in FULL). The
# remaining two l's and the core go together when the site turns bare.
SHED_ORDER = ((0, 1), (1, 4), (4, 2), (3, 0), (0, 3))

# Stage edges as fractions of the loop.
U_SWELL, U_HALF, U_FULL, U_SHED, U_BARE = .10, .20, .30, .80, .88
SHED_AT = tuple(.80 + .016 * j for j in range(5))


def _cells(grid):
    """[(dy, dx, key)] for every opaque cell, relative to the centre cell."""
    cy, cx = len(grid) // 2, len(grid[0]) // 2
    return [(y - cy, x - cx, ch) for y, row in enumerate(grid)
            for x, ch in enumerate(row) if ch != "."]


def _flat(grid, swap=False, drop=()):
    """Flatten a grid to [(dy, dx, idx)]; swap b<->l on the twinkle beat."""
    cy, cx = len(grid) // 2, len(grid[0]) // 2
    out = []
    for dy, dx, ch in _cells(grid):
        if (dy + cy, dx + cx) in drop:
            continue
        idx = SPRITE_KEYS[ch]
        if swap and ch == "b":
            idx = I_PETAL_LT
        out.append((dy, dx, idx))
    return out


# Every sprite variant the loop can need, flattened once.
SP_SWELL = _flat(SWELL)
SP_HALF = _flat(HALF)
SP_FULL = (_flat(FULL), _flat(FULL, swap=True))
SP_SHED = [_flat(FULL, drop=SHED_ORDER[:n]) for n in range(6)]


# --- the static layer -----------------------------------------------------------

def _bezier(p0, p1, p2, t):
    a, b, c = (1 - t) ** 2, 2 * (1 - t) * t, t * t
    return (a * p0[0] + b * p1[0] + c * p2[0], a * p0[1] + b * p1[1] + c * p2[1])


def _limb(buf, p0, p1, p2, thick, branch, hi_every=7):
    """Rasterise one tapering limb, column by column (both limbs are monotone
    in x). Body is BARK_DK with a BARK top edge, every `hi_every`th top pixel
    catching light as BARK_HI; a 1-px tip stays all BARK_DK. `thick` is
    (trunk end, tip) in px."""
    cols = {}
    steps = 1200
    for i in range(steps + 1):
        t = i / float(steps)
        x, y = _bezier(p0, p1, p2, t)
        xi = int(round(x))
        if xi not in cols:
            cols[xi] = (y, t)
    spine = []
    prev = None
    for n, xi in enumerate(sorted(cols, reverse=True)):
        y, t = cols[xi]
        top = int(round(y))
        th = max(1, int(round(thick[0] + (thick[1] - thick[0]) * t)))
        # Close the gap a steep step would leave between neighbouring columns.
        lo = top if prev is None else min(top, prev + 1)
        for yy in range(lo, top + th):
            _put(buf, xi, yy, I_BARK_DK, branch)
        # The BARK edge only where there is body under it: at th == 1 it would
        # overwrite the one BARK_DK pixel, and BARK alone all but vanishes
        # into the dusk bands (the same reason _twig is drawn in BARK_DK).
        if th >= 2:
            _put(buf, xi, top, I_BARK_HI if n % hi_every == 3 else I_BARK, branch)
        spine.append((xi, top, t))
        prev = top
    return spine


def _put(buf, x, y, idx, branch=None):
    if 0 <= x < WIDTH and 0 <= y < HEIGHT:
        buf[y * WIDTH + x] = idx
        if branch is not None:
            branch.add((x, y))


def _twig(buf, x0, y0, angle, length, up, branch, leaves):
    """1-px twig toward the upper or lower left, shortened to stay on screen
    and inside the y <= 60 box; a 2x1 leaf pair (dark over light) at its tip."""
    dx, dy = -math.cos(angle), (-1 if up else 1) * math.sin(angle)
    while length > 3:                       # shorten until the tip fits the box
        ty = y0 + dy * length
        if 1 <= ty and ty + 1 <= 58:
            break
        length -= 1
    pts = []
    for i in range(1, length + 1):
        x, y = int(round(x0 + dx * i)), int(round(y0 + dy * i))
        if not pts or pts[-1] != (x, y):
            pts.append((x, y))
    for x, y in pts:
        # BARK_DK, not BARK: BARK sits within a few levels of the dusk bands
        # and a BARK twig simply was not there.
        _put(buf, x, y, I_BARK_DK, branch)
    tx, ty = pts[-1]
    _put(buf, tx - 1, ty, I_LEAF_DK)
    _put(buf, tx - 1, ty + 1, I_LEAF)
    leaves.add((tx - 1, ty))
    leaves.add((tx - 1, ty + 1))
    return pts


def _cloud_mask(cx, base, width, salt):
    """Pixels of one puff: five circles cut off flat at `base`, a little
    jittered per cloud (by noise, so every build is identical)."""
    cells = set()
    for k, (fx, fr) in enumerate(((-.34, .12), (-.17, .19), (0, .24),
                                  (.17, .18), (.34, .11))):
        ox = cx + width * (fx + .06 * (noise(salt, k, 41) - .5))
        r = width * fr * (.88 + .24 * noise(salt, k, 43))
        oy = base - r * .45
        for y in range(int(oy - r) - 1, base + 1):
            for x in range(int(ox - r) - 1, int(ox + r) + 2):
                if (x + .5 - ox) ** 2 + (y + .5 - oy) ** 2 <= r * r:
                    cells.add((x, y))
    return cells


def _cloud(buf, cx, base, width, salt):
    """One static puff: a 1-px white rim along its top and left edge and over
    its top sixth, the body, a 2-px shade above a 1-px warm underside (the
    morning light), the shade also down its right edge."""
    cells = _cloud_mask(cx, base, width, salt)
    top = min(y for _x, y in cells)
    bottom = {}
    for x, y in cells:
        bottom[x] = max(y, bottom.get(x, y))
    cap = top + max(1, int(round((base - top) * .16)))
    for x, y in cells:
        if y == bottom[x]:
            idx = I_CLOUD_WARM
        elif y >= bottom[x] - 2 or (x + 1, y) not in cells:
            idx = I_CLOUD_SH
        elif (x, y - 1) not in cells or (x - 1, y) not in cells or y < cap:
            idx = I_CLOUD_HI
        else:
            idx = I_CLOUD
        _put(buf, x, y, idx)


def _morning(buf):
    """The sky variant's static layer under the limbs: gradient, haze, clouds."""
    for k in range(SKY_BANDS):
        a = SKY_BAND_SLOT[k]
        b = SKY_BAND_SLOT[min(k + 1, SKY_BANDS - 1)]
        for y in range(9 * k, 9 * k + 9):
            row = bytes((a,)) * WIDTH
            if y == 9 * k + 8 and k < SKY_BANDS - 1:
                row = bytes(b if (x + y) % 2 == 0 else a for x in range(WIDTH))
            buf[y * WIDTH:(y + 1) * WIDTH] = row
    assert 9 * SKY_BANDS == LOW_ROW
    buf[LOW_ROW * WIDTH:] = bytes((I_BG,)) * (WIDTH * (HEIGHT - LOW_ROW))
    # Haze: 1-px streaks, warmer lower down, their ends thinned to every
    # other pixel so they fade in and out rather than stop.
    lo, hi = HAZE_ROWS
    for j in range(9):
        y = lo + 1 + j * 3 + int(noise(j, 51) * 2)
        if y > hi:
            continue
        length = 50 + int(noise(j, 53) * 90)
        x0 = int(noise(j, 57) * (WIDTH + length)) - length // 2
        idx = I_HAZE[min(len(I_HAZE) - 1, (y - lo) * len(I_HAZE) // (hi - lo + 1))]
        for i in range(length):
            edge = min(i, length - 1 - i)
            if edge < 6 and (i + y) % 2:
                continue
            _put(buf, x0 + i, y, idx)
    for n, (cx, base, width) in enumerate(CLOUDS):
        _cloud(buf, cx, base, width, n)


def _background():
    """Bands, limbs, twigs and leaves: everything that never moves."""
    buf = bytearray(WIDTH * HEIGHT)
    if is_sky():
        _morning(buf)
    else:
        for i in range(8):
            for y in range(9 * i, 9 * i + 9):
                row = bytes((i,)) * WIDTH
                if y == 9 * i + 8 and i < 7:
                    # Checkerboard the last row of each band into the next
                    # one, so the dusk has no hard edges.
                    row = bytes(i + 1 if (x + y) % 2 == 0 else i for x in range(WIDTH))
                buf[y * WIDTH:(y + 1) * WIDTH] = row
        buf[DUSK_ROW * WIDTH:] = bytes((I_BG,)) * (WIDTH * (HEIGHT - DUSK_ROW))

    branch, leaves = set(), set()
    main = ((319, 4), (250, 0), (150, 38))
    second = ((319, 46), (292, 40), (252, 58))
    # Thicker than the 3->1 / 2->1 first sketch: at 6 screen px per art px a
    # 1-2 px limb vanished into the dusk bands.
    _limb(buf, main[0], main[1], main[2], MAIN_THICK, branch)
    _limb(buf, second[0], second[1], second[2], SECOND_THICK, branch)
    for limb, ts, salt in ((main, (.2, .35, .5, .65, .8), 0),
                           (second, (.3, .55, .8), 100)):
        for j, t in enumerate(ts):
            t += 0.05 * (noise(salt + j, 11) - 0.5) * 2
            x, y = _bezier(limb[0], limb[1], limb[2], t)
            angle = math.radians(30 + 30 * noise(salt + j, 13))
            length = 8 + int(noise(salt + j, 17) * 10)
            _twig(buf, x, round(y), angle, length, j % 2 == 1, branch, leaves)

    assert all(x >= 140 and y <= 60 for x, y in branch | leaves), "limb left its box"
    return bytes(buf), sorted(branch), leaves


def _pick_sites(branch, leaves, n=34):
    """`n` blossom sites on the wood, no two within Chebyshev distance 4."""
    cands = [(x, y) for x, y in branch
             if 142 <= x <= 317 and 1 <= y <= 58 and (x, y) not in leaves]
    sites = []
    tries = 0
    while len(sites) < n and tries < 20000:
        x, y = cands[int(noise(tries, 71) * len(cands))]
        tries += 1
        if all(max(abs(x - a), abs(y - b)) > 4 for a, b, _o in sites):
            sites.append((x, y, int(noise(len(sites), 5) * LOOP)))
    return sites


BACKGROUND = None              # of the variant _prepare() last served
SITES = None
_PREPARED = {}                 # variant -> (background, sites)


def _prepare():
    global BACKGROUND, SITES
    v = BP.variant()
    if v not in _PREPARED:
        background, branch, leaves = _background()
        _PREPARED[v] = (background, _pick_sites(branch, leaves))
    BACKGROUND, SITES = _PREPARED[v]
    return BACKGROUND, SITES


# --- frames ---------------------------------------------------------------------

def _petal_colour(y, light):
    """Petals fade as they fall: by row, so rows 72-125 only ever hold the
    three dusk indices (10, 12, 14) and nothing at all reaches row 126."""
    if y < DUSK_ROW:
        return I_PETAL_LT if light else I_PETAL_MID
    if y < 100:
        return I_PETAL_LT
    if y < 114:
        return I_PETAL_SH
    return I_BARK_HI


def _petal(buf, x, y, f, k):
    """Two-pixel petal, fluttering between flat ("lm") and edge-on (l over m)."""
    if ((f // 6) + k) % 2:
        cells = ((x, y, True), (x + 1, y, False))
    else:
        cells = ((x, y, True), (x, y + 1, False))
    if y >= SINGLE_ROW:
        cells = cells[:1]           # far down, a petal is a single fading dot
    for px, py, light in cells:
        if 0 <= px < WIDTH and 0 <= py < LOW_ROW:
            buf[py * WIDTH + px] = _petal_colour(py, light)


def _stamp(buf, x, y, sprite):
    for dy, dx, idx in sprite:
        px, py = x + dx, y + dy
        if 0 <= px < WIDTH and 0 <= py < HEIGHT:
            buf[py * WIDTH + px] = idx


def _edge(u):
    return int(round(u * LOOP))


E_SWELL, E_HALF, E_FULL, E_SHED, E_BARE = (_edge(u) for u in
                                           (U_SWELL, U_HALF, U_FULL, U_SHED, U_BARE))
E_DETACH = tuple(_edge(u) for u in SHED_AT)


def stage(site, f):
    """Stage name of blossom `site` (an entry of SITES) at frame f."""
    u = (f * SUB + site[2]) % LOOP
    if u < E_SWELL:
        return "BUD"
    if u < E_HALF:
        return "SWELL"
    if u < E_FULL:
        return "HALF"
    if u < E_SHED:
        return "FULL"
    if u < E_BARE:
        return "SHED"
    return "BARE"


def frame(f):
    """Index buffer for frame f. Not reduced modulo FRAMES on purpose: every
    term is periodic on its own, which is what verify_seamless relies on."""
    background, sites = _prepare()
    buf = bytearray(background)

    # Blossoms on the wood.
    for i, site in enumerate(sites):
        x, y, off = site
        u = (f * SUB + off) % LOOP
        if u < E_SWELL:
            _put(buf, x, y, I_BUD)
        elif u < E_HALF:
            _stamp(buf, x, y, SP_SWELL)
        elif u < E_FULL:
            _stamp(buf, x, y, SP_HALF)
        elif u < E_SHED:
            _stamp(buf, x, y, SP_FULL[((f // 24) + i) % 2])   # 48-frame twinkle
        elif u < E_BARE:
            gone = sum(1 for e in E_DETACH if u >= e)
            _stamp(buf, x, y, SP_SHED[gone])

    # Shed petals: each detaches in place at its edge, then falls 3 px per 4
    # frames with a sideways wobble and a wind drift right (wider than the
    # first sketch's 1/12, which left every blossom a speckled clump below it). From y0 >= 0 it has
    # left the dusk band (row 126) by age 168, so it never wraps visibly.
    cy, cx = len(FULL) // 2, len(FULL[0]) // 2
    for i, (x, y, off) in enumerate(sites):
        for j, (r, cc) in enumerate(SHED_ORDER):
            # Own wobble phase per petal, so a blossom's five petals spread
            # out as they fall instead of sinking as one speckled clump.
            phase = 2 * math.pi * (noise(i, 5) + noise(i, j, 7))
            # First frame whose loop position reaches this petal's edge.
            birth = (-((off - E_DETACH[j]) // SUB)) % FRAMES
            age = (f - birth) % FRAMES
            py = y + (r - cy) + age * 3 // 4
            if py >= LOW_ROW:
                continue
            wob = 2.5 * (math.sin(2 * math.pi * age / 48 + phase) - math.sin(phase))
            px = x + (cc - cx) + int(round(wob)) + age // DRIFT
            _petal(buf, px, py, f, i * 5 + j)

    # Ambient petals, always falling, across the whole width.
    for k in range(18):
        phk = noise(k, 9)
        a = (f + int(phk * FRAMES)) % FRAMES
        py = -4 + a * 130 // FRAMES
        px = (int(noise(k, 3) * WIDTH) + a * 20 // FRAMES
              + int(round(2 * math.sin(2 * math.pi * f / 48 + 2 * math.pi * phk)))) % WIDTH
        _petal(buf, px, py, f, k)
    return buf


# --- checks ----------------------------------------------------------------------

def verify_seamless():
    """Frame 0 and frame FRAMES must be identical, or the loop visibly jumps."""
    assert frame(0) == frame(FRAMES), "loop is not seamless"
    return True


def assert_band_invariant(frames=None):
    """Rows 126-179 pure BG in every frame; rows 72-125 only BG or petals
    (sky: anything but wood, buds, blossoms and leaves)."""
    flat = bytes((I_BG,)) * (WIDTH * (HEIGHT - LOW_ROW))
    ok = frozenset(range(PALETTE_LEN)) - WOOD if is_sky() else DUSK_OK
    for f in range(FRAMES):
        buf = frames[f] if frames is not None else frame(f)
        assert bytes(buf[LOW_ROW * WIDTH:]) == flat, "frame %d: art in the bed band" % f
        dusk = set(buf[DUSK_ROW * WIDTH:LOW_ROW * WIDTH])
        assert dusk <= ok, "frame %d: indices %s in the dusk band" % (
            f, sorted(dusk - ok))
    return True


def verify_gif(path):
    """Walk the GIF block by block (not a byte search) and check its shape:
    header and size, a NETSCAPE2.0 loop, exactly FRAMES full-size images with
    no local colour table, every GCE at disposal 1 and DELAY_CS, the 0x3B
    trailer last, and the byte budget."""
    with open(path, "rb") as fh:
        d = fh.read()
    if len(d) > MAX_BYTES:
        raise ValueError("%d bytes > MAX_BYTES" % len(d))
    if d[:6] != b"GIF89a":
        raise ValueError("not GIF89a")
    w, h, flags = struct.unpack("<HHB", d[6:11])
    if (w, h) != (WIDTH, HEIGHT):
        raise ValueError("size %dx%d" % (w, h))
    if not flags & 0x80 or (2 << (flags & 7)) != PALETTE_LEN:
        raise ValueError("no %d-entry global colour table" % PALETTE_LEN)
    pos = 13 + 3 * PALETTE_LEN

    def skip_sub(p):
        while d[p]:
            p += d[p] + 1
        return p + 1

    images = gces = 0
    looped = False
    while True:
        if pos >= len(d):
            raise ValueError("no trailer")
        b = d[pos]
        if b == 0x3B:
            if pos != len(d) - 1:
                raise ValueError("bytes after the trailer")
            break
        if b == 0x21:
            label = d[pos + 1]
            if label == 0xF9:
                if d[pos + 2] != 4:
                    raise ValueError("bad GCE size")
                disposal = (d[pos + 3] >> 2) & 7
                delay = struct.unpack("<H", d[pos + 4:pos + 6])[0]
                if disposal != 1 or delay != DELAY_CS:
                    raise ValueError("GCE disposal %d delay %d" % (disposal, delay))
                gces += 1
            elif label == 0xFF and d[pos + 2] == 11 and d[pos + 3:pos + 14] == b"NETSCAPE2.0":
                looped = True
            pos = skip_sub(pos + 2)
        elif b == 0x2C:
            # Every frame is a whole, non-interlaced 320x180 image on the one
            # global palette: a local table would mean the palette (and with
            # it the R1/R3 colour guarantees) had drifted per frame.
            box = struct.unpack("<HHHH", d[pos + 1:pos + 9])
            iflags = d[pos + 9]
            if box != (0, 0, WIDTH, HEIGHT):
                raise ValueError("image %d is a %r sub-rectangle" % (images, box))
            if iflags & 0xC0:
                raise ValueError("image %d has a local table or interlace" % images)
            pos = skip_sub(pos + 11)                # min code size, then data
            images += 1
        else:
            raise ValueError("unknown block 0x%02X at %d" % (b, pos))
    if not looped:
        raise ValueError("no NETSCAPE2.0 loop block")
    if images != FRAMES or gces != FRAMES:
        raise ValueError("%d images, %d GCEs, expected %d" % (images, gces, FRAMES))
    return True


# --- output -----------------------------------------------------------------------

def build(path, variant_name=None):
    """Write the GIF atomically (pid-suffixed tmp, verified, then os.replace).
    Returns the size in bytes; on any error the tmp is removed and it re-raises.
    `variant_name` ("pink" / "sky"): draw that variant (default: the active
    one); blossompal's variant is put back afterwards."""
    if variant_name is not None:
        with variant(variant_name):
            return build(path)
    pal = palette()
    frames = [bytes(frame(f)) for f in range(FRAMES)]
    assert_band_invariant(frames)
    assert frames[0] == bytes(frame(FRAMES)), "loop is not seamless"
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = "%s.%d.tmp" % (path, os.getpid())
    try:
        # Opaque frames on one global palette: disposal 1 is correct and the
        # smallest, and stays inside the 0-3 WT's XAML decoder will play.
        size = gifwriter.write_gif(tmp, WIDTH, HEIGHT, pal, frames,
                                   delay_cs=DELAY_CS, transparent_index=None,
                                   loop=0, disposal=1)
        verify_gif(tmp)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    return size


if __name__ == "__main__":
    import time
    argv = sys.argv[1:]
    which = "pink"
    if "--variant" in argv:
        i = argv.index("--variant")
        which = argv[i + 1] if i + 1 < len(argv) else ""
        del argv[i:i + 2]
    out = argv[0] if argv else os.path.join(__import__("tempfile").gettempdir(), "blossom-preview")
    t0 = time.time()
    with variant(which):
        path = os.path.join(out, file_name())
        n = build(path)
    print("%s: %d KB, %.1f s" % (path, n // 1024, time.time() - t0))
