"""Blossom palette: the ONLY place any blossom colour is defined.

Every blossom surface reads its colours from here and nowhere else:

  blossom.py              the status line panel (blossom heads + SOIL info row);
                          blossomflower.py holds their key grids, no colours
  blossomgif.py           the Windows Terminal background GIF (sky bands, limb)
  sl-blossom-wt.py        the WT colour scheme (SCHEME, passed verbatim)
  make_blossom_theme.py   the Claude Code UI theme (CC_FILLS, backdrops, audits)
  preview_blossom.py      the PNG previews (composites over BG)

Cohesion rules this module encodes:

  R1  One colour owns the terminal. BG #6B0F3A (a dark raspberry pink) is the
      WT scheme background,
      GIF palette index 7 (the flat bottom 60 % of every frame and every pad
      slot), the opaque panel field, CC clawd_background and part of the CC
      solver's TERM backdrop. BANDS[7] == BG == SCHEME["background"] ==
      CC_FILLS["clawd_background"].
  R3  Depth is a contrast rule. Every GIF art colour has relative luminance
      <= 0.105 (GIF_ART_MAX is the brightest), so TEXT #FBE4F0 stays >= 5.7:1
      over any GIF pixel; the panel flowers are vivid and read as near.

Values are uppercase "#RRGGBB" strings; hx() turns one into an (r, g, b)
tuple. Contrast figures in the comments are WCAG ratios recomputed when the
palette moved from plum #4A1238 to dark pink #6B0F3A. They are
documentation only: make_blossom_theme.py re-measures every one of them on each
dry run (section C audits) and never trusts these.

VARIANTS. Two themes share this palette: "blossom" (the dark pink above, the
default the module loads as) and "blossomsky" (the same flowers under a pastel
morning sky). use("sky") rebinds ONLY the background-dependent names (the
surface, sky bands, soil, twinkles, back-row hazes, GIF art, WT scheme, CC
fills, the 256-colour table) from _SKY; use("pink") puts the originals back.
Every flower, leaf and info-row colour is shared, so the sky panel is pixel
for pixel the pink one wherever a flower is. Call use() BEFORE reading names
(blossom.py re-reads them through blossom.variant()). R1 holds per variant;
R3 becomes "every GIF art colour keeps the scheme foreground >= 4.6:1", which
on the light sky means art lum >= GIF_ART_LUM[0] instead of <= [1].

Pure data, stdlib only, no side effects on import. Deliberately has no
DESCRIPTION line, so the status line dispatcher never lists it as a theme.
"""


def hx(s): return tuple(int(s[i:i+2], 16) for i in (1, 3, 5))


# --- surface -------------------------------------------------------------------
BG = "#6B0F3A"              # lum 0.0377, hue 332 deg, dark pink: owns the terminal (R1)
BG_TOP = "#4B0A29"          # darkest sky band, top of the window (BG x 0.70: still pink)
# GIF palette indices 0-7, top to bottom; index 7 is the flat lower 60 %.
BANDS = ["#4B0A29", "#500B2B", "#540B2E", "#590C30",
         "#5D0D33", "#620E35", "#660E38", "#6B0F3A"]
SOIL = "#3C0820"            # status line info row (BG x 0.56); TEXT on it 13.99
SELECTION = "#842A57"       # WT selectionBackground + CC selectionBg:
                            # 1.40 vs BG (visible), fg 7.13, every ANSI fg >= 3.6

# --- GIF art: every value lum <= 0.105 (asserted by blossomgif + the audit) ------
BARK_DK = "#1C0610"         # limb body (index 8); 1.27-1.62 on the bands
BARK = "#2D0A1A"            # limb top edge, twigs (index 9); a dark silhouette:
                            # 1.17 on BG_TOP .. 1.44 on band 6 (was 1.10)
BARK_HI = "#732A49"         # every 7th top-edge pixel; low falling petals (10), 1.23 vs BG
BUD_FAR = "#7C2C4E"         # 1-px bud (11)
PETAL_SH = "#7C2E4D"        # petal shadow; mid-height falling petals (12)
PETAL_MID = "#873252"       # (13)
PETAL_LT = "#903557"        # petal light; upper falling petals (14)
PETAL_MAX = "#98385C"       # lum 0.1028, the brightest GIF colour (15), 1.74 vs BG
CENTRE_FAR = "#7A4E2C"      # blossom centre (16)
LEAF_DK = "#204A30"         # twig-tip leaf, top (17)
LEAF_FAR = "#2F5E3E"        # twig-tip leaf, bottom (18)
GIF_ART_MAX = PETAL_MAX     # CC `text` is also audited against this (the art
                            # colour with the WORST text contrast; sky: BARK_DK)
GIF_ART_LUM = (0.0, 0.105)  # (min, max) relative luminance of every art colour
# Sky-only GIF extras; the pink dusk has none (empty = not drawn).
GIF_GRADIENT = ()           # sky: 14 bands, a straight lerp BG_TOP -> BG
CLOUD = ()                  # sky: (top highlight, body, shade, warm underside)
HAZE = ()                   # sky: thin 1-px morning-haze streaks, low in the sky

# --- blossom heads: the panel's big cherry blossoms (contrast on BG) ----------
# One ramp per tint, keyed like blossomflower.GRIDS: o soft pink outline,
# w white rim, l pale petal, p petal pink, m medium (petal base / shadow),
# d deep crease, s magenta streak (veins, stamen filaments), r red heart,
# k dark red core, y yellow anther, n orange anther. Tint 0 is the base pink
# ramp. Every head is ringed by its outline o, which is the only key that
# ever touches the background.
BLOSSOM = {"o": "#F28DB6",          # 5.28
           "w": "#FFF8FA",          # 11.43
           "l": "#FEE7EF",          # 10.20
           "p": "#FECDDE",          # 8.55
           "m": "#FEB4CE",          # 7.20
           "d": "#F08EB8",          # 5.28
           "s": "#EE5797",          # 3.67
           "r": "#EF1F53",          # 2.84, always inside the petals
           "k": "#B80E30",          # 1.79, always inside the heart
           "y": "#FEF100",          # 10.14
           "n": "#FE7E26"}          # 4.69
BLOSSOM_WHITE = dict(BLOSSOM, o="#F4A6C6", l="#FFF3F7", p="#FFE3EC",     # o 6.34
                     m="#FDCCDD", d="#F5A9C8")
BLOSSOM_MEDIUM = dict(BLOSSOM, o="#EC6FA4", w="#FFEAF2", l="#FFD3E4",    # o 4.20
                      p="#FDB3CF", m="#F897BD", d="#EC79AA", s="#E2427F")
BLOSSOM_DEEP = dict(BLOSSOM, o="#DF4F8E", w="#FFDCEA", l="#FFBDD7",      # o 3.22
                    p="#F99BC1", m="#F07AAB", d="#E25E98", s="#D42F6E",
                    r="#E0143F")
# blossom.py's tint index -> ramp (0 base pink, 1 white-pink, 2 medium, 3 deep)
BLOSSOM_TINTS = (BLOSSOM, BLOSSOM_WHITE, BLOSSOM_MEDIUM, BLOSSOM_DEEP)
TWINKLE = "#FEF100"         # 10.14, the 4-point sparkles around open heads
TWINKLE_HI = "#FFFBD0"      # 11.38, a big sparkle's pale core
# Back rows of a tall panel (full height) are pushed toward BLOSSOM_HEAD_HAZE
# by these mixes, nearest row first: further back reads dimmer, like distance.
BLOSSOM_ROW_MIX = (0.30, 0.42, 0.52, 0.60, 0.66, 0.70)
BLOSSOM_HEAD_HAZE = BG      # pink: the background itself (sky: a dusty rose)
# Sakura leaves behind the heads (blossomleaf.py keys): o 1-px outline, d the
# shaded half, g the lit half, v the light midrib. Soft sap greens, a little
# yellow so they sit warm on the pink instead of turning neon. Back rows mix
# them by BLOSSOM_ROW_MIX toward BLOSSOM_LEAF_HAZE, darker and greyer than BG:
# toward BG itself the greens went khaki; this way they recede into shadow.
BLOSSOM_LEAF = {"o": "#1D3F27",     # 1.02, a dark rim (the pink shows the shape)
                "d": "#3F7A43",     # 2.32
                "g": "#5E9E4D",     # 3.69
                "v": "#9DCB72"}     # 6.39
BLOSSOM_LEAF_HAZE = "#2A1624"   # a dark low-chroma plum: greens stay green

# --- legacy flower-bed colours (the earlier stem-and-species bed) ------
# No longer drawn by blossom.py. Kept, unchanged, because make_blossom_theme.py
# still names them (its species rows and C256 coverage list).

# --- panel greens (contrast on BG) ----------------------------------------------
STEM = "#3E8E52"            # 2.96, decor
STEM_DK = "#2F5E3E"         # the continuous grass line / seam above the soil
LEAF = "#6CC47A"            # 5.59
BUD = "#8FD18A"             # 6.64
MOSS_ALT = "#3E7A4A"        # grass variation

# --- species -------------------------------------------------------------------
# Ramp keys: d shade, p petal, P main petal, h highlight; optional c centre and
# o its outer ring. Contrast on BG in the comments. CORNFLOWER and SAKURA have
# a DARK eye (c), which is always surrounded by petals in every grid.
ROSE = {"d": "#D63A7E",     # 2.72
        "p": "#FF6FAE",     # 4.64
        "P": "#FF9FCB",     # 6.31
        "h": "#FFE0EF"}     # 9.78
TULIP = {"d": "#E0604A",    # 3.39
         "p": "#FF8A70",    # 5.20
         "P": "#FFB59E",    # 7.04
         "h": "#FFE3D8"}    # 9.82
DAISY = {"d": "#E8B8CF",    # 6.95
         "p": "#FFE0EF",
         "P": "#FFF4F8",    # 11.14
         "h": "#FFFFFF",
         "c": "#FFD34D",    # 8.37
         "o": "#F29A2E"}    # 5.38
COSMOS = {"d": "#9B6FE0",   # 3.27
          "p": "#C9A0FF",   # 5.67
          "P": "#E2CCFF",
          "h": "#F6EEFF",
          "c": "#FFD34D",
          "o": "#F29A2E"}
MARIGOLD = {"d": "#D9802A",  # 4.03
            "p": "#FFB43C",  # 6.75
            "P": "#FFD45A",  # 8.44
            "h": "#FFF0B0"}  # 10.45
CORNFLOWER = {"d": "#5F7FE0",  # 3.19
              "p": "#8CB4FF",  # 5.75
              "P": "#B8D4FF",  # 7.92
              "h": "#EAF2FF",
              "c": "#2E3F9A"}  # dark eye
SAKURA = {"d": "#E07AA8",   # 4.29
          "p": "#FFB7D5",   # 7.40
          "P": "#FFD8E8",   # 9.26
          "h": "#FFF2F7",
          "c": "#C2306A"}   # dark eye

SPECIES_ORDER = ("ROSE", "TULIP", "DAISY", "COSMOS", "MARIGOLD", "CORNFLOWER", "SAKURA")
# name -> ramp dict (the same objects as the module-level names above).
SPECIES = {"ROSE": ROSE, "TULIP": TULIP, "DAISY": DAISY, "COSMOS": COSMOS,
           "MARIGOLD": MARIGOLD, "CORNFLOWER": CORNFLOWER, "SAKURA": SAKURA}
# back-row colours = lerp_rgb(col, hx(BG), BACK_MIX). 0.40 turned the warm
# species muddy (MARIGOLD tan/brown, ROSE maroon); 0.28 keeps them floral and
# still clearly dimmer than the front row.
BACK_MIX = 0.28
SPARKLE = "#FFFFFF"         # the opening flash on h pixels

# --- panel extras ----------------------------------------------------------------
AMBIENT = ("#FFD1E3", "#F59ABF")    # drifting petals: 8.82, 5.85
FLY_F = "#FFF0A8"           # butterfly wing
FLY_f = "#F2B65C"           # butterfly wing edge
FLY_k = "#7B3F30"           # butterfly body: warm brown, LIGHTER than BG (1.48),
                            # so the closed frame no longer shows a near-black dot

# --- info row (contrast on SOIL; every one >= 4.5) -----------------------------
TEXT = "#FBE4F0"            # 13.99
LABEL = "#C08AAA"           # 5.98
SEP = "#D27098"             # 5.22 (a colour; the separator string is blossom.SEP)
CTX_OK = "#8EE6A0"          # 11.20, ctx < 50 %
CTX_WARN = "#FFD98A"        # 12.46, ctx < 80 %
CTX_HOT = "#FF7A8A"         # 6.73, ctx >= 80 % and failed agents
MODEL = "#FF9FCB"           # 8.88
PATH = "#F2D6E6"            # 12.45
BRANCH = "#C9A0FF"          # 7.98
COST = "#FFD98A"
AGENTS = "#8EE8E0"          # 11.84
BLOOM = "#FF9FCB"           # "N/M in bloom"
# The info-row colours above are for SOIL. Pink: the bare fallback lines (the
# narrow `* ctx N%` row, the last-resort error row) print straight on BG,
# which they also read on. Sky: pastel text on a light sky does not, so they
# are put on SOIL too.
BARE_TEXT_ON_SOIL = False

# --- Windows Terminal colour scheme (21 keys, used verbatim) -------------------
# background == GIF index 7 == panel BG. Every ANSI fg slot is >= 5.0:1 on BG
# (fg 9.95, red 5.32, brightBlack 5.04) and >= 6.4 on BG_TOP; red and
# brightBlack are lifted so they stay >= 3.6 on the selection (3.81, 3.61).
# black is a near-black pink (BG x 0.34), used only as a background.
SCHEME = {"name": "Blossom",
          "background": "#6B0F3A", "foreground": "#FBE4F0",
          "cursorColor": "#FF9FCB", "selectionBackground": "#842A57",
          "black": "#240514", "red": "#FF8A98", "green": "#8EE6A0", "yellow": "#FFD98A",
          "blue": "#9CC4FF", "purple": "#E0A8FF", "cyan": "#8EE8E0", "white": "#F2D6E6",
          "brightBlack": "#CB9AB6", "brightRed": "#FF9EAA", "brightGreen": "#B0F0BE",
          "brightYellow": "#FFE7B0", "brightBlue": "#BCD8FF", "brightPurple": "#ECC6FF",
          "brightCyan": "#B4F2EC", "brightWhite": "#FFF5FA"}

# --- Claude Code fixed substrates (14) -------------------------------------------
# Not solved: make_blossom_theme.py uses them verbatim (FILLS = CC_FILLS) and
# audits the solved roles against them. Comments: lum, TEXT contrast on it.
CC_FILLS = {
    "userMessageBackground":      "#721E48",   # .050, text 8.75
    "userMessageBackgroundHover": "#7A224E",   # .058, text 8.06 (panel fills < .06)
    "composerSidebarBackground":  "#530E2E",   # .024, text 11.88
    "memoryBackgroundColor":      "#6D1B47",   # .045, text 9.20
    "bashMessageBackgroundColor": "#4C1643",   # .025, text 11.61 (hue 310, off BG)
    "selectionBg":                SELECTION,   # text 7.13
    "clawd_background":           BG,          # R1
    "rate_limit_empty":           "#7A224E",
    # diffs: added green-dominant, removed red-dominant and >= 25 deg off BG's hue
    # (removed sit at hue 3-4 deg, 28-29 deg from BG's 332; lums kept as before)
    "diffAdded":                  "#1F4A33",   # .0543
    "diffAddedDimmed":            "#173A29",   # .0337
    "diffAddedWord":              "#2A7046",   # .1252, text 4.98
    "diffRemoved":                "#6E201C",   # .0443
    "diffRemovedDimmed":          "#511A17",   # .0255
    "diffRemovedWord":            "#A4362E",   # .1073, text 5.55
}

# --- 256-colour fallback: "#RRGGBB" -> xterm index ------------------------------
# Covers every colour blossom.py's fallback path emits except the dimmed back
# rows of a tall panel (computed mixes, mapped to the nearest xterm colour at
# run time). Legacy entries are kept with their palette. Several hexes are
# shared between roles (MODEL == BLOOM == ROSE P, COST == CTX_WARN, BRANCH ==
# COSMOS p); a shared hex always maps to the same index.
C256 = {
    # info row
    TEXT: 225, PATH: 224, LABEL: 175, SEP: 168, CTX_OK: 114, CTX_WARN: 222,
    CTX_HOT: 210, MODEL: 218, BRANCH: 183, AGENTS: 116, COST: 222, BLOOM: 218,
    # greens
    STEM: 65, STEM_DK: 22, LEAF: 71, BUD: 114, MOSS_ALT: 65,
    # species main colour P
    ROSE["P"]: 218, TULIP["P"]: 216, DAISY["P"]: 231, COSMOS["P"]: 183,
    MARIGOLD["P"]: 221, CORNFLOWER["P"]: 153, SAKURA["P"]: 225,
    # species shade d
    ROSE["d"]: 168, TULIP["d"]: 167, DAISY["d"]: 182, COSMOS["d"]: 140,
    MARIGOLD["d"]: 172, CORNFLOWER["d"]: 69, SAKURA["d"]: 175,
    # centres
    "#FFD34D": 221,
    # surfaces
    BG: 89, SOIL: 52,         # 89 #87005F: 53 is nearer but reads purple, not pink
    # blossom heads, every tint (nearest xterm pink; the pale petal l is 225,
    # not the nearer grey 255, so pale fronts stay pink instead of grey)
    "#F28DB6": 211, "#FFF8FA": 231, "#FEE7EF": 225, "#FECDDE": 224,
    "#FEB4CE": 218, "#F08EB8": 211, "#EE5797": 204, "#EF1F53": 197,
    "#B80E30": 125, "#FEF100": 226, "#FE7E26": 208,
    "#F4A6C6": 218, "#FFF3F7": 231, "#FFE3EC": 225, "#FDCCDD": 224, "#F5A9C8": 218,
    "#EC6FA4": 205, "#FFEAF2": 231, "#FFD3E4": 224, "#FDB3CF": 218, "#F897BD": 211,
    "#EC79AA": 211, "#E2427F": 168,
    "#DF4F8E": 168, "#FFDCEA": 224, "#FFBDD7": 218, "#F99BC1": 211, "#F07AAB": 211,
    "#E25E98": 168, "#D42F6E": 161, "#E0143F": 161,
    TWINKLE_HI: 230,
    # sakura leaves
    "#1D3F27": 22, "#3F7A43": 65, "#5E9E4D": 71, "#9DCB72": 150,
}

# --- variants: "pink" (theme blossom, the names above) and "sky" (blossomsky) ---
# _SKY overrides ONLY what depends on the background; everything not named here
# (every head ramp and outline, BLOSSOM_LEAF, BLOSSOM_ROW_MIX, AMBIENT, FLY_*,
# the species, every info-row colour) is shared by both variants. The sky
# variant is a pastel morning sky (its own BLOSSOM_HEAD_HAZE, a straight-lerp
# BANDS, a per-variant GIF_ART_LUM). Polarity flips: DARK navy text on a light sky, so the CC UI
# theme is base "light" and GIF art must be LIGHT (lum >= GIF_ART_LUM[0], so
# the navy foreground keeps >= 4.6:1 over every GIF pixel). Contrast figures
# are on the sky BG unless noted.
_SKY = {
    # surface (R1: BANDS[7] == BG == SCHEME background == CC clawd_background)
    "BG": "#C9E1F4",                # lum 0.728, powder blue; navy fg 10.45
    "BG_TOP": "#8DBFEB",            # zenith; navy fg 7.25
    "BANDS": ["#8DBFEB", "#96C4EC", "#9EC9EE", "#A7CEEF",       # straight lerp
              "#AFD2F0", "#B8D7F1", "#C0DCF3", "#C9E1F4"],      # BG_TOP -> BG
    "SOIL": "#14263F",              # deep navy info row: TEXT 12.66, LABEL 5.41,
                                    # SEP 4.72, CTX_HOT 6.09, the rest >= 7.2
    "SELECTION": "#9DC2E5",         # 1.38 vs BG, navy fg 7.58
    # GIF art: light, every value lum >= 0.2924 (navy fg >= 4.6:1)
    "BARK_DK": "#9E8FA3",           # misty mauve-grey limb, fg 4.64
    "BARK": "#B3A3B6",              # fg 5.93
    "BARK_HI": "#E7D3E0",
    "BUD_FAR": "#F2C3D6",
    "PETAL_SH": "#EBD3E2",
    "PETAL_MID": "#F3C0D4",
    "PETAL_LT": "#F7CFDE",
    "PETAL_MAX": "#F5B3CB",
    "CENTRE_FAR": "#E7B9A0",
    "LEAF_DK": "#93BB9C",
    "LEAF_FAR": "#A9CDA9",
    "GIF_ART_MAX": "#9E8FA3",       # == BARK_DK: the worst text contrast here
    "GIF_ART_LUM": (0.2924, 1.0),
    "GIF_GRADIENT": ("#8DBFEB", "#92C2EC", "#96C4EC", "#9BC7ED", "#9FC9EE",
                     "#A4CCEE", "#A9CFEF", "#ADD1F0", "#B2D4F1", "#B7D7F1",
                     "#BBD9F2", "#C0DCF3", "#C4DEF3", "#C9E1F4"),
    "CLOUD": ("#FFFFFF", "#F3F8FD", "#E1EAF5", "#F6E6EA"),     # fg 11.3-14.1
    "HAZE": ("#D3E3F1", "#DCE4EF", "#E5E4EC"),
    # panel back rows. TWINKLE stays the pink theme's #FEF100 (it matches the
    # anthers and reads crisply by hue on the pale sky; gold #FFD21F was tried).
    "BLOSSOM_LEAF_HAZE": "#B4CFE0",  # back-row leaves recede into pale sage
    "BLOSSOM_HEAD_HAZE": "#E8C3D6",  # dusty rose: back-row heads stay pink as
                                     # they recede (toward BG they went lilac)
    "BARE_TEXT_ON_SOIL": True,
    # Windows Terminal "Blossom Sky": every ANSI fg >= 5.0 on BG (normals ~6,
    # brights ~5) and >= 3.6 on the selection; cursor 3.96 (a shape); white /
    # brightWhite are dark slates (GitHub-light style) so white text reads.
    "SCHEME": {"name": "Blossom Sky",
               "background": "#C9E1F4", "foreground": "#1C2B48",
               "cursorColor": "#C2306A", "selectionBackground": "#9DC2E5",
               "black": "#1C2B48", "red": "#9A1A3E", "green": "#1E5B2E",
               "yellow": "#6B4900", "blue": "#204D95", "purple": "#703392",
               "cyan": "#0E5862", "white": "#485568",
               "brightBlack": "#4D5C72", "brightRed": "#A92753",
               "brightGreen": "#206833", "brightYellow": "#7A5400",
               "brightBlue": "#2A5AA6", "brightPurple": "#7D3EA3",
               "brightCyan": "#0E656E", "brightWhite": "#374661"},
    # Claude Code fixed substrates (navy text contrast in the comments)
    "CC_FILLS": {
        "userMessageBackground":      "#B6D4EE",   # 9.16
        "userMessageBackgroundHover": "#ABCDEA",   # 8.50
        "composerSidebarBackground":  "#BCD8F0",   # 9.55
        "memoryBackgroundColor":      "#C2D3F0",   # 9.32
        "bashMessageBackgroundColor": "#D3D0EF",   # 9.43, lavender, off BG hue
        "selectionBg":                "#9DC2E5",   # SELECTION
        "clawd_background":           "#C9E1F4",   # BG (R1)
        "rate_limit_empty":           "#ABCDEA",
        "diffAdded":                  "#C3E6CB",
        "diffAddedDimmed":            "#D3EBD8",
        "diffAddedWord":              "#93D0A2",   # 7.92
        "diffRemoved":                "#F3CCD5",
        "diffRemovedDimmed":          "#F2DCE2",
        "diffRemovedWord":            "#E9A2B3",   # 6.91
    },
}
# 256 colours: the pink table without its two surfaces, plus the sky ones.
_SKY["C256"] = dict({k: v for k, v in C256.items() if k not in (BG, SOIL)},
                    **{"#C9E1F4": 153, "#14263F": 17})

_THEMES = {"pink": "blossom", "sky": "blossomsky"}
_PINK = {name: globals()[name] for name in _SKY}    # the originals, for use("pink")
_current = "pink"


def use(name):
    """Rebind the background-dependent names to variant `name` ("pink" or
    "sky", or a theme name "blossom" / "blossomsky"); returns the previous
    variant. Unknown names raise ValueError and change nothing."""
    global _current
    name = {v: k for k, v in _THEMES.items()}.get(name, name)
    if name not in _THEMES:
        raise ValueError("unknown blossom variant %r" % (name,))
    prev = _current
    globals().update(_SKY if name == "sky" else _PINK)
    _current = name
    return prev


def variant():
    """The active variant: "pink" or "sky"."""
    return _current


def theme_name(name=None):
    """Status line theme of a variant (default: the active one): "blossom" or
    "blossomsky". Also the stem of its files (blossomsky-bg-v1.gif, ...)."""
    return _THEMES[_current if name is None else name]
