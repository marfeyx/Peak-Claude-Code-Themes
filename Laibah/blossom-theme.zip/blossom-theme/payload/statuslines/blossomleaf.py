"""Blossom leaves: the green sakura leaves behind blossom.py's heads.

Each head gets a small cluster of 2-3 overlapping leaves fanning out from
behind its heart, so the row reads like a flowering branch. A leaf is
rasterised here as palette keys (no colours; blossompal.BLOSSOM_LEAF maps
them): an ovate blade, widest a third of the way up, with a rounded base and
a drawn-out pointed tip, ringed by a 1-px dark outline o, a light midrib v
from base to near the tip, the half that faces the light (top-left) in leaf
green g and the other half in shade d.

blossom.py draws the leaves UNDER everything: it fills only pixels that no
head or twinkle took, so the flower art is never touched.

Pure functions, stdlib only, memoised; never raises on sane input.
"""
import math

KEYS = "odgv"               # o outline, d shade half, g lit half, v midrib
_A, _B = 0.55, 1.20         # profile s^A (1-s)^B: round base, pointed tip
_PEAK = (_A / (_A + _B)) ** _A * (_B / (_A + _B)) ** _B

_SPRITES = {}


def _half(s):
    """Half-width of the blade at s (0 base .. 1 tip), as a fraction of max."""
    if s <= 0.0 or s >= 1.0:
        return 0.0
    return s ** _A * (1.0 - s) ** _B / _PEAK


def leaf(length, width, angle):
    """[(dx, dy, key)] of one leaf whose base is pixel (0, 0), pointing
    `angle` degrees (0 right, -90 up), `length` px long and `width` px across
    at its widest. Memoised per (length, width, angle) rounded to ints."""
    key = (int(round(length)), int(round(width)), int(round(angle)) % 360)
    got = _SPRITES.get(key)
    if got is not None:
        return got
    L, wd, a = max(3, key[0]), max(2, key[1]), math.radians(key[2])
    c, s = math.cos(a), math.sin(a)
    hw = wd / 2.0
    # the light comes from the top-left: the half whose normal (-s, c) faces
    # it is lit (g), the other is in shade (d)
    lit = 1.0 if (s - c) > 0 else -1.0

    def uv(x, y):
        """(u along the blade, v across it), or None outside the blade."""
        u = x * c + y * s
        v = -x * s + y * c
        return (u, v) if 0.0 <= u <= L and abs(v) <= hw * _half(u / L) + 0.2 else None

    tx, ty = L * c, L * s                               # scan only the blade's box
    x0, x1 = int(min(0, tx) - hw - 2), int(max(0, tx) + hw + 2)
    y0, y1 = int(min(0, ty) - hw - 2), int(max(0, ty) + hw + 2)
    cells = {}
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            got = uv(x, y)
            if got is not None:
                cells[(x, y)] = got
    # a long blade gets side veins: pairs leaving the midrib toward the tip
    veins = [0.30, 0.50, 0.68] if L >= 20 else []
    out = []
    for (x, y), (u, v) in cells.items():
        side = v * lit >= 0
        if any(n not in cells for n in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1))):
            k = "o"
        elif abs(v) <= 0.5 and 0.10 * L <= u <= 0.84 * L:
            k = "v"
        elif any(abs(u - (f * L + 0.9 * abs(v))) <= 0.5 for f in veins):
            k = "d" if side else "g"                    # a vein: the other half's tone
        else:
            k = "g" if side else "d"
        out.append((x, y, k))
    out.sort(key=lambda e: (e[1], e[0]))
    _SPRITES[key] = out
    return out


# One cluster per head, as (angle deg, length and base offset as fractions of
# the head width, blade width as a fraction of its length). Two leaves rise
# into the gaps either side of the head; on about half the heads a third, on
# alternating sides, overlaps one of them, fanned out a little more upright
# or a little lower (on all of them the gaps would fill edge to edge).
_FAN = ((-152.0, 0.72, 0.38), (-28.0, 0.72, 0.38))
_THIRD = ((-124.0, 0.62, 0.40), (-174.0, 0.60, 0.38))
THIRD_SHARE = 0.5


def rise(length, width, angle):
    """How far a leaf's highest edge pixel sits above its base (px)."""
    a = math.radians(angle)
    up, across = -math.sin(a), abs(math.cos(a))
    return max(f * length * up + width / 2.0 * _half(f) * across + 1.0
               for f in (0.2, 0.33, 0.5, 0.7, 0.9, 1.0))


def reach(length, width, angle):
    """How far a leaf's outermost edge pixel sits sideways of its base (px)."""
    a = math.radians(angle)
    out, down = abs(math.cos(a)), abs(math.sin(a))
    return max(f * length * out + width / 2.0 * _half(f) * down + 1.0
               for f in (0.2, 0.33, 0.5, 0.7, 0.9, 1.0))


def cluster(width, seed, jitter, room=None, side=None):
    """[(angle, length, blade width, base offset)] for a head `width` px
    wide. `seed` picks the side of the third leaf, `jitter(n)` -> [0, 1)
    varies angle and length a little per leaf (in four steps each, so a long
    row reuses a handful of memoised sprites instead of rasterising each) and
    whether there is a third leaf at all. `room` (px above the base, or None)
    and `side` ((px left, px right) of the base, or None) keep tips inside
    the panel: a leaf that would poke out of the top first leans up to 30 deg
    toward the horizontal, one that would poke out of a side leans toward the
    vertical while the top allows it; then it shortens (to about 0.6x at
    most), so the panel edges rarely slice a blade flat."""
    out = []
    flip = seed % 2 == 1
    specs = list(_FAN)
    if jitter(13) < THIRD_SHARE:
        specs.append(_THIRD[(seed // 2) % 2])

    def step(n):
        return int(jitter(n) * 4.0) / 3.0               # 0, 1/3, 2/3, 1

    def fits(L, bw, ang):
        if room is not None and rise(L, bw, ang) > room:
            return False
        if side is not None:
            return reach(L, bw, ang) <= side[0 if math.cos(math.radians(ang)) < 0 else 1]
        return True

    for n, (ang, ln, bw) in enumerate(specs):
        if n == 2 and flip:
            ang = -180.0 - ang
        ang += (step(n) - 0.5) * 16.0
        L = width * ln * (0.86 + 0.28 * step(n + 7))
        bw *= L
        if room is not None:
            for _ in range(6):                          # lean, 5 deg at a time
                if rise(L, bw, ang) <= room:
                    break
                ang += -5.0 if ang < -90.0 else 5.0
        if side is not None:
            for _ in range(6):                          # stand up, while the top allows
                if fits(L, bw, ang):
                    break
                up = ang + (5.0 if ang < -90.0 else -5.0)
                if room is not None and rise(L, bw, up) > room:
                    break
                ang = up
        while L > 0.62 * width * ln and not fits(L, bw, ang):
            L -= 1.0                                    # then shorten
            bw = L * bw / (L + 1.0)
        out.append((ang, L, bw, width * 0.08))
    return out
