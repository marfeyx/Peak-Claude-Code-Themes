"""Blossom status line: a row of big pixel-art cherry blossoms along the bottom
of a dark pink terminal, each head slowly opening and closing on its own clock.

The whole window is dark pink because Windows Terminal's background is
blossomgif.py's GIF (a sakura limb top-right, a flat BP.BG lower band) and
sl-blossom-wt.py sets the matching scheme (optional; without it the
panel paints its own dark pink). This module paints only the PANEL:
rows 0..H-2 are half-block pixel art, row H-1 is the info row on soil.

The heads are blossomflower.py's hand-drawn sakura grids (24, 36 or 48 px
wide, six stages from a closed teardrop bud to a scalloped full bloom), original
pixel art: pastel petals with white rims inside a soft pink outline, a red
heart with radiating stamens tipped yellow and orange.
Only the TOP of each head shows: the row is cropped by the info row, so what
you watch is the top opening and closing. Each head runs an 18 s cycle (bud
hold, four opening steps, a full-bloom hold, four closing steps; every step
>= 1.2 s, the refresh is 1 s), phases staggered by the golden ratio so the
row always holds heads at different stages and, from 3 heads up, at least one
in bloom. Yellow 4-point twinkles sparkle around open heads (on background
pixels only). Heads alternate big / small where the panel allows it, vary in
tint (base pink, white-pink, medium, deep) and the more open a head is,
the further behind its neighbours it is drawn. A tall panel (e.g. `full`)
stacks back rows of smaller, dimmer, complete heads behind the front row,
each tucked behind the one in front, so the field is never mostly empty.

Green sakura leaves (blossomleaf.py: ovate blades with a dark rim, a light
midrib and a shaded half) fan out in clusters of 2-3 from behind every head,
so the row reads like a flowering branch. They are drawn UNDER everything:
a leaf only fills a pixel no head or twinkle took, so the flowers are pixel
for pixel what they are without leaves. Back-row leaves recede with their
row (blossompal.BLOSSOM_LEAF_HAZE); tips lean in rather than poke out of
the top or the sides of the panel. Static: positions follow the layout.

TRANSPARENCY: the art cells leave bg unset (\\033[49m) only when the blossom
GIF really is the WT background (WT_SESSION set and statusline-wt-applied
names blossom-bg-*); otherwise they are painted BG so the flowers never float
on a foreign sky. The info row is always opaque SOIL. SL_BLOSSOM_OPAQUE=1/0
forces either way. Colours all come from blossompal.py.

VARIANTS: blossompal also carries a "sky" variant (the same panel under a
pastel morning sky, selected with variant("sky")). It is not used by this
pack; the default "pink" variant is what renders.

256 colours (STATUSLINE_NO_TRUECOLOR): the same heads, mapped through
blossompal.C256 (computed back-row mixes go to the nearest xterm colour); the
leaves only fill cells no head or twinkle touches.

Stateless: every animation is derived from time.time(). Writes no files (only
the shared /tmp caches of common.git_branch and agentcount); never raises.

Height: SL_BLOSSOM_HEIGHT, else <install dir>/statusline-blossom-height (written
by `/blossom N|full|auto`). auto -> 8 rows on 20+ line terminals (24 px
heads), 11 rows on 36+ (36 px heads); 1 or 2 -> info row only; full -> the
terminal minus 4 (capped at 80). The head size follows the art height: the
biggest whose cropped top fits, as long as the row still holds ~2 heads (on a
narrow terminal: one whole head, centred). SL_BLOSSOM_BLEED=0 keeps the art
(in both colour modes) off the right gutter.
"""

DESCRIPTION = "Blossom: big pixel-art cherry blossoms open and close among green leaves along the bottom of a dark pink terminal"

import contextlib
import gc
import math
import os
import time
import unicodedata

from common import (Canvas, Pixels, RESET, dig, env_int, git_branch, lerp_rgb,
                    short_path, term_size, truecolor)
import blossomflower as BF
import blossomleaf as BL
import blossompal as BP

try:
    import agentcount
except Exception:  # pragma: no cover - agents segment is optional
    agentcount = None


# --- palette (blossompal.py is the only source; nothing is defined here) ----
def _hx(v):
    """'#RRGGBB' (or an rgb sequence) -> (r, g, b) tuple."""
    if isinstance(v, str):
        return (int(v[1:3], 16), int(v[3:5], 16), int(v[5:7], 16))
    return tuple(int(x) for x in v[:3])


def _palette():
    """Every colour this module paints, derived from blossompal's ACTIVE
    variant: {global name: value}. _bind() installs it."""
    g = {"BG": _hx(BP.BG), "SOIL": _hx(BP.SOIL),
         "TEXT": _hx(BP.TEXT), "LABEL": _hx(BP.LABEL),
         "SEPC": _hx(BP.SEP),                           # BP.SEP is a colour here
         "CTX_OK": _hx(BP.CTX_OK), "CTX_WARN": _hx(BP.CTX_WARN),
         "CTX_HOT": _hx(BP.CTX_HOT), "MODEL": _hx(BP.MODEL), "PATH": _hx(BP.PATH),
         "BRANCH": _hx(BP.BRANCH), "COST": _hx(BP.COST), "AGENTS": _hx(BP.AGENTS),
         "BLOOM": _hx(BP.BLOOM),
         "TWINKLE": _hx(BP.TWINKLE), "TWINKLE_HI": _hx(BP.TWINKLE_HI)}
    # HEAD_PAL[row][tint] = {grid key: rgb}. Row 0 is the front row at full
    # colour; back row j is pushed BP.BLOSSOM_ROW_MIX[j-1] toward the head
    # haze (pink: BG itself).
    row_mix = (0.0,) + tuple(float(m) for m in BP.BLOSSOM_ROW_MIX)
    haze = _hx(BP.BLOSSOM_HEAD_HAZE)
    g["ROW_MIX"] = row_mix
    g["HEAD_PAL"] = tuple(tuple({k: lerp_rgb(_hx(v), haze, m) for k, v in ramp.items()}
                                for ramp in BP.BLOSSOM_TINTS)
                          for m in row_mix)
    g["N_TINTS"] = len(BP.BLOSSOM_TINTS)
    # LEAF_PAL[row] = {leaf key: rgb}, dimmed per row like the heads.
    g["LEAF_PAL"] = tuple({k: lerp_rgb(_hx(v), _hx(BP.BLOSSOM_LEAF_HAZE), m)
                           for k, v in BP.BLOSSOM_LEAF.items()} for m in row_mix)
    # 256-colour fallback: rgb -> xterm index, from blossompal's hex-keyed
    # table; anything else (the dimmed back rows) goes to the nearest xterm
    # colour. One dict per variant: c256() memoises into it.
    table = {}
    for k, v in BP.C256.items():
        try:
            table[_hx(k)] = int(v)
        except (TypeError, ValueError, IndexError):
            pass
    g["C256"] = table
    g["BARE_ON_SOIL"] = bool(getattr(BP, "BARE_TEXT_ON_SOIL", False))
    g["THEME"] = BP.theme_name() if hasattr(BP, "theme_name") else "blossom"
    return g


_BOUND = {}                 # variant -> _palette(), built once per process


def _bind():
    """Install the colours of blossompal's active variant as this module's
    globals (BG, HEAD_PAL, C256, ...)."""
    key = BP.variant() if hasattr(BP, "variant") else "pink"
    got = _BOUND.get(key)
    if got is None:
        got = _BOUND[key] = _palette()
    globals().update(got)


_bind()


@contextlib.contextmanager
def variant(name):
    """Run the block with blossompal's variant `name` ("pink" / "sky") and
    this module's colours bound to it; both are put back afterwards."""
    prev = BP.use(name)
    try:
        _bind()
        yield
    finally:
        BP.use(prev)
        _bind()


_LEVELS = (0, 95, 135, 175, 215, 255)
_XTERM = [(16 + i, (_LEVELS[i // 36], _LEVELS[i // 6 % 6], _LEVELS[i % 6])) for i in range(216)]
_XTERM += [(232 + i, (8 + 10 * i,) * 3) for i in range(24)]


def _hue_sat(rgb):
    """(hue in degrees, saturation 0..1) of an rgb tuple."""
    r, g, b = (v / 255.0 for v in rgb)
    hi, lo = max(r, g, b), min(r, g, b)
    if hi == lo:
        return 0.0, 0.0
    d = hi - lo
    h = ((g - b) / d % 6 if hi == r else (b - r) / d + 2 if hi == g else (r - g) / d + 4)
    return h * 60.0, d / hi


_XTERM_HS = [_hue_sat(rgb) for _i, rgb in _XTERM]


def c256(rgb, default=None):
    """xterm index of an rgb: blossompal.C256's pick, else the nearest xterm
    colour of about the same hue (plain nearest turns dim pinks grey-brown)."""
    got = C256.get(rgb)
    if got is None:
        try:
            r, g, b = (int(v) for v in rgb)
            hue, sat = _hue_sat((r, g, b))
            pool = _XTERM
            if sat > 0.15:
                near = [e for e, (eh, es) in zip(_XTERM, _XTERM_HS)
                        if es > 0.25 and abs((eh - hue + 180) % 360 - 180) <= 20]
                pool = near or _XTERM
            got = min(pool, key=lambda e: (2 * (e[1][0] - r) ** 2 + 4 * (e[1][1] - g) ** 2
                                           + 3 * (e[1][2] - b) ** 2))[0]
        except Exception:
            return 225 if default is None else default
        C256[rgb] = got                                 # memo for this process
    return got


# --- timing and layout constants -------------------------------------------
# One head's cycle: (stage index, seconds). A closed hold, four opening steps,
# a full-bloom hold, four closing steps. Every step >= 1.2 s, so a 1 s refresh
# shows every stage on the way up and down.
CYCLE = ((0, 3.0), (1, 1.4), (2, 1.4), (3, 1.4), (4, 1.4), (5, 4.6),
         (4, 1.2), (3, 1.2), (2, 1.2), (1, 1.2))
PERIOD = sum(d for _st, d in CYCLE)                     # 18 s
IN_BLOOM = 4                # stages >= this count as "in bloom" (0.8 and 1.0)
GOLDEN = 0.6180339887
OVERLAP = 0.86              # centre step = mean head width * OVERLAP
MIN_OVERLAP = 0.76          # ... squeezed to this if that fits one more head
TUCK = 0.50                 # a back-row head hides this much of its height
SKY = 0.15                  # back rows stop below this fraction of the field
MAX_ROWS = len(ROW_MIX)     # front row + back rows (the same for every variant)
# tint weights: base pink, white-pink, medium, deep
TINT_CDF = (0.40, 0.62, 0.86, 1.0)

SEP = "  ·  "          # "  ·  "  (WGL4 / Cascadia, no emoji)
MIN_W = 20
INFO_ONLY_W = 32

_HERE = os.path.dirname(os.path.abspath(__file__))
_CLAUDE_DIR = os.path.dirname(_HERE)
HEIGHT_FILE = os.path.join(_CLAUDE_DIR, "statusline-blossom-height")
APPLIED_FILE = os.path.join(_CLAUDE_DIR, "statusline-wt-applied")

DEMO = {"model": {"display_name": "Opus 5.5"}, "cost": {"total_cost_usd": 3.17},
        "worktree": {"branch": "main"}, "context_window": {"used_percentage": 37},
        "workspace": {"current_dir": "~/proj"}}

M64 = 0xFFFFFFFFFFFFFFFF


def noise(*key):
    """Deterministic hash in [0, 1) (splitmix64, as meadow.py): stable scenery."""
    h = 0x9E3779B97F4A7C15
    for k in key:
        h = (h + (int(k) & M64) + 0x9E3779B97F4A7C15) & M64
        h = ((h ^ (h >> 30)) * 0xBF58476D1CE4E5B9) & M64
        h = ((h ^ (h >> 27)) * 0x94D049BB133111EB) & M64
        h ^= h >> 31
    return (h & 0xFFFFFFFF) / 4294967296.0


# --- defensive input helpers (as pacman.py) ----------------------------------
def _int(v, lo, hi, default=None):
    """Clamped int, or default for bools, non-numbers and non-finite floats."""
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)):
        try:
            if isinstance(v, float) and not math.isfinite(v):
                return default
            return max(lo, min(hi, int(v)))
        except (OverflowError, ValueError):
            return default
    return default


def _float(v, default=None):
    """Finite float, or default (bools rejected)."""
    if isinstance(v, bool):
        return default
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        return default
    return f if math.isfinite(f) else default


def char_cols(ch):
    """Terminal columns of one character (east-asian wide = 2)."""
    return 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1


def text_cols(s):
    """Terminal columns of a string."""
    return sum(char_cols(ch) for ch in s)


def clean(value, limit=48):
    """Payload field -> printable single-line string (no control chars or marks)."""
    if value is None:
        return ""
    if not isinstance(value, str):
        value = str(value)
    value = unicodedata.normalize("NFC", value)
    out = "".join(ch for ch in value
                  if ch >= " " and ch != "\x7f" and not unicodedata.combining(ch)
                  and unicodedata.category(ch) not in ("Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp"))
    out = out.encode("utf-8", "replace").decode("utf-8")   # belt and braces: never unencodable
    if text_cols(out) > limit:
        kept, used = [], 0
        for ch in out:
            used += char_cols(ch)
            if used > limit - 1:
                break
            kept.append(ch)
        out = "".join(kept) + "…"
    return out


def pct_label(pct):
    """The integer every path prints for a context percentage (half rounds up)."""
    return int(math.floor(pct + 0.5))


def context_pct(d):
    """context_window.used_percentage clamped to 0..100 (0 for junk)."""
    v = _float(dig(d, "context_window", "used_percentage"))
    return 0.0 if v is None else max(0.0, min(100.0, v))


def agents_of(d):
    """(done, total, failed) from agentcount, sanitised, or None."""
    if agentcount is None:
        return None
    try:
        got = agentcount.progress(d)
        if not got:
            return None
        done, total, failed = (int(x) for x in got[:3])
    except Exception:
        return None
    total = max(0, total)
    done = max(0, min(done, total))
    failed = max(0, min(failed, done))
    return (done, total, failed) if total else None


# --- height and transparency --------------------------------------------------
def _height_names():
    """Theme names whose height setting applies, own first: blossomsky falls
    back to blossom's, so switching keeps the panel the same height."""
    return (THEME,) if THEME == "blossom" else (THEME, "blossom")


def height_setting():
    """Per theme name, own first: SL_<THEME>_HEIGHT, then the file /sl
    writes (statusline-<theme>-height); "" when none is set. So for
    blossomsky `/sl blossomsky N` beats blossom's env var and file."""
    names = _height_names()
    for name in names:
        raw = os.environ.get("SL_%s_HEIGHT" % name.upper(), "").strip().lower()
        if raw:
            return raw
        path = HEIGHT_FILE if name == "blossom" else \
            os.path.join(_CLAUDE_DIR, "statusline-%s-height" % name)
        try:
            with open(path) as fh:
                raw = fh.read(64).strip().lower()
        except (OSError, UnicodeDecodeError):
            continue
        if raw or name == names[-1]:
            return raw
    return ""


def panel_height(lines=None):
    """Total rows H (art + info row): 1, or 3..80."""
    if lines is None:
        lines = term_size()[1]
    lines = _int(lines, -1000, 100000, 24)
    raw = height_setting()
    if raw == "full":
        return min(80, max(6, lines - 4))
    try:
        n = int(raw)
    except ValueError:
        n = None
    if n is not None:
        if n <= 2:
            return 1
        return min(80, max(3, min(n, max(3, lines - 2))))
    # auto / garbage: 8 rows (24 px heads) on 20+ lines, 11 (36 px) on 36+
    return max(5, min(11 if lines >= 36 else 8, lines - 12))


def is_opaque():
    """True unless this variant's GIF (blossom-bg-* / blossomsky-bg-*) is
    verifiably the WT background right now."""
    force = os.environ.get("SL_BLOSSOM_OPAQUE", "").strip()
    if force in ("0", "1"):
        return force == "1"
    if not os.environ.get("WT_SESSION"):
        return True
    try:
        with open(APPLIED_FILE, "rb") as fh:            # apply_file writes it,
            head = fh.read(64)                          # restore() deletes it
    except OSError:
        return True
    return not head.startswith((THEME + "-bg-").encode("ascii"))

# --- layout (static: positions never jump between frames) --------------------
def pick_size(W, F):
    """Front-row head size for W columns and F px of art: the biggest whose
    cropped top fits (one row of slack) and leaves ~2 heads across; else the
    biggest that fits once; 24 px if nothing fits (a short panel crops more)."""
    fit = [s for s in BF.SIZES if BF.crop_rows(s) <= F + 1] or [BF.SIZES[0]]
    for s in reversed(fit):
        if W >= 1.7 * s:
            return s
    for s in reversed(fit):
        if W >= s:
            return s
    return fit[0]


def smaller(size):
    i = BF.SIZES.index(size)
    return BF.SIZES[max(0, i - 1)]


def _front_x(W, big, small):
    """[(x0, size)] for the front row across 0..W-1: big and small heads
    alternate, stepped OVERLAP of their mean width apart (squeezed down to
    MIN_OVERLAP if that fits one more head), then spread over the width and
    centred. One head, centred, if only one fits."""
    def centres(k):
        sizes, cs, c = [], [], None
        while len(cs) < 400:
            s = big if len(cs) % 2 == 0 else small
            w = BF.dims(s)[0]
            c = w / 2.0 if c is None else c + (BF.dims(sizes[-1])[0] + w) / 2.0 * k
            if c + w / 2.0 > W:
                break
            cs.append(c)
            sizes.append(s)
        return cs, sizes
    cs, sizes = centres(OVERLAP)
    if not cs:                                          # narrower than one head
        return [((W - BF.dims(big)[0]) // 2, big)]
    tight = centres(MIN_OVERLAP)
    if len(tight[0]) > len(cs):                         # one more head, a bit closer
        cs, sizes = tight
    n = len(cs)
    left = W - (cs[-1] + BF.dims(sizes[-1])[0] / 2.0)
    extra = min(left / (n + 1.0), 0.25 * BF.dims(small)[0]) if n > 1 else 0.0
    margin = (left - extra * (n - 1)) / 2.0
    out = []
    for i, (c, s) in enumerate(zip(cs, sizes)):
        w = BF.dims(s)[0]
        x0 = int(round(margin + c + extra * i - w / 2.0))
        out.append((max(0, min(W - w, x0)), s))
    return out


def _back_x(W, big, small, ahead, row):
    """[(x0, size)] for a back row: one head over every gap of the row in
    front (`ahead`, its [(x0, size)]) and one past each end, like brickwork,
    so back heads peek out between the front ones. A little jitter."""
    cs = [x0 + BF.dims(s)[0] / 2.0 for x0, s in ahead]
    if len(cs) > 1:
        step = (cs[-1] - cs[0]) / (len(cs) - 1)
    else:
        step = BF.dims(ahead[0][1])[0] * OVERLAP if ahead else W / 2.0
    want = [cs[0] - step / 2.0] + [(a + b) / 2.0 for a, b in zip(cs, cs[1:])] \
        + [cs[-1] + step / 2.0] if cs else [W / 2.0]
    out = []
    for i, c in enumerate(want):
        s = big if i % 2 else small
        w = BF.dims(s)[0]
        x0 = int(round(c - w / 2.0)) + int(noise(row, i, 87) * 5) - 2
        if x0 < -w // 3 or x0 + w > W + w // 3:          # mostly off the panel
            continue
        out.append((max(0, min(W - w, x0)), s))
    return out


def _tint(row, i, prev):
    u = noise(row, i, 91)
    tint = min(N_TINTS - 1, next(k for k, cdf in enumerate(TINT_CDF)
                                 if u < cdf or k == len(TINT_CDF) - 1))
    return (tint + 1) % N_TINTS if tint == prev else tint


def layout(W, F):
    """[(row, i, x0, y0, size, tint, phase)] for every head, front row first.

    Row 0 stands on the field bottom: every head's grid is cropped at its own
    crop_rows(), so big and small heads share one ground line (a panel shorter
    than the crop shows the top of the head instead: grid row 1 at the top).
    Back row j: smaller heads, drawn whole, over the gaps of the row in front
    with their bottom TUCK tucked behind its top; rows are added while a whole
    head still fits below the top SKY of the field."""
    W, F = max(1, int(W)), max(1, int(F))
    big = pick_size(W, F)
    small = smaller(big)
    heads = []
    ahead, front_top = None, None
    for row in range(MAX_ROWS):
        if row:
            big, small = small, smaller(small)
            h = BF.dims(big)[1]
            y_big = front_top + int(TUCK * h) - h
            if y_big < max(1, int(SKY * F)):                # keep some sky on top
                break
            xs = _back_x(W, big, small, ahead, row)
        else:
            xs = _front_x(W, big, small)
        prev, top = None, None
        for i, (x0, s) in enumerate(xs):
            if row == 0:
                crop = BF.crop_rows(s)
                y0 = F - crop if F >= crop else -min(1, crop - F)
            else:                                       # receptacles on one line
                y0 = y_big + int(round(BF.CENTRE[1] * (BF.dims(big)[0] - BF.dims(s)[0])))
            tint = _tint(row, i, prev)
            prev = tint
            phase = (i * GOLDEN + 0.1 + 0.29 * row) % 1.0
            heads.append((row, i, x0, y0, s, tint, phase))
            top = y0 if top is None else min(top, y0)
        if top is None:
            break
        ahead, front_top = xs, top
    return heads


def stage_at(t, phase):
    """Stage index (0 bud .. BF.FULL bloom) of a head at time t."""
    s = (t + phase * PERIOD) % PERIOD
    for st, d in CYCLE:
        if s < d:
            return st
        s -= d
    return 0


# --- the blossom heads (rows 0 .. H-2) ----------------------------------------
_INK = {}


def _ink(size, stage):
    """[(gx, gy, key)] of a grid's non-transparent pixels (memoised)."""
    got = _INK.get((size, stage))
    if got is None:
        got = [(gx, gy, k) for gy, line in enumerate(BF.grid(size, stage))
               for gx, k in enumerate(line) if k != "."]
        _INK[(size, stage)] = got
    return got


def draw_head(px, x0, y0, size, stage, pal, t, W, F):
    """Blit one head; at the open stages one anther tip in five swaps yellow /
    orange once a second (a slow glint)."""
    d = px.px
    glint = stage >= 3
    tick = int(t) if math.isfinite(t) else 0
    for gx, gy, k in _ink(size, stage):
        x, y = x0 + gx, y0 + gy
        if 0 <= x < W and 0 <= y < F:
            if glint and k in "yn" and (gx * 7 + gy * 3 + tick) % 5 == 0:
                k = "n" if k == "y" else "y"
            d[(x, y)] = pal[k]


def leaf_layer(heads, W, F):
    """{(x, y): rgb} of the leaves behind every head: back rows first, so a
    nearer cluster overlaps a further one; static (they never sway)."""
    out = {}
    for row, i, x0, y0, s, tint, ph, st in sorted(heads, key=lambda e: (-e[0], e[2])):
        w, h = BF.dims(s)
        cx, cy = x0 + w * BF.CENTRE[0], y0 + h * BF.CENTRE[1]
        pal = LEAF_PAL[row]
        edge = w * 0.08                                 # the base sits this far out
        for ang, ln, bw, off in BL.cluster(w, row * 31 + i,
                                           lambda n: noise(row, i, 61, n),
                                           cy - 0.5 if row == 0 else None,
                                           (cx - edge, W - 1 - cx - edge)):
            a = math.radians(ang)
            bx = int(round(cx + off * math.cos(a)))
            by = int(round(cy + off * math.sin(a)))
            for dx, dy, k in BL.leaf(ln, bw, ang):
                x, y = bx + dx, by + dy
                if 0 <= x < W and 0 <= y < F:
                    out[(x, y)] = pal[k]
    return out


def draw_field(cv, W, H, t, whole_cells=False):
    """Paint the heads onto rows 0..H-2; returns (in bloom, front heads).

    The leaves go in last, on background pixels only, so no head or twinkle
    pixel ever changes; whole_cells (the 256-colour path) also keeps them out
    of any cell a head or twinkle already touches."""
    F = 2 * (H - 1)
    if F < 2:
        return 0, 0
    px = Pixels(W, H - 1)
    heads = [(row, i, x0, y0, s, tint, ph, stage_at(t, ph))
             for row, i, x0, y0, s, tint, ph in layout(W, F)]
    # back rows first; within a row the more open a head, the further behind
    for row, i, x0, y0, s, tint, ph, st in sorted(heads, key=lambda e: (-e[0], -e[7], e[2])):
        draw_head(px, x0, y0, s, st, HEAD_PAL[row][tint], t, W, F)
    taken = px.px
    for row, i, x0, y0, s, tint, ph, st in heads:       # twinkles on background only
        for dx, dy, hi in BF.twinkle_points(s, st, t, row * 31 + i):
            x, y = x0 + dx, y0 + dy
            if 0 <= x < W and 0 <= y < F and (x, y) not in taken:
                taken[(x, y)] = TWINKLE_HI if hi else TWINKLE
    art = set(taken) if whole_cells else taken
    for (x, y), rgb in leaf_layer(heads, W, F).items():  # leaves under everything:
        if (x, y) not in art and not (whole_cells and (x, y ^ 1) in art):
            taken[(x, y)] = rgb                         # only pixels left empty
    px.flush(cv)
    front = [e for e in heads if e[0] == 0]
    return sum(1 for e in front if e[7] >= IN_BLOOM), len(front)


def bloom_count(W, t):
    """(in bloom, heads) of the 8-row front row, for the info-row-only paths."""
    front = [e for e in layout(W, 14) if e[0] == 0]
    return sum(1 for e in front if stage_at(t, e[6]) >= IN_BLOOM), len(front)

# --- the info row (row H-1) ---------------------------------------------------
def info_parts(d, pct, agents, bloom, tw):
    """Fitted (left, right, right_width); sides are [(prio, [(text, fg)])]."""
    shown = pct_label(pct)                              # the colour follows the number
    pc = CTX_OK if shown < 50 else CTX_WARN if shown < 80 else CTX_HOT
    left = [(6, [("ctx ", LABEL), ("%d%%" % shown, pc)])]
    if agents:
        done, total, failed = agents
        segs = [("agents %d/%d" % (done, total), AGENTS)]
        if failed:
            segs.append(("  %d failed" % failed, CTX_HOT))
        left.append((5, segs))
    cwd = None
    try:
        cwd = dig(d, "workspace", "current_dir") or d.get("cwd") or os.getcwd()
        if isinstance(cwd, str) and cwd:
            left.append((3, [(clean(short_path(cwd, 32), 40), PATH)]))
        else:
            cwd = None
    except Exception:
        cwd = None
    branch = ""
    try:
        branch = clean(dig(d, "worktree", "branch") or "", 40)
        if not branch and cwd:
            branch = clean(git_branch(cwd) or "", 40)
    except Exception:
        branch = ""
    if branch:
        left.append((2, [(branch, BRANCH)]))
    model = clean(dig(d, "model", "display_name") or dig(d, "model", "id") or "", 32)
    if model:
        left.append((1, [(model, MODEL)]))
    cost = _float(dig(d, "cost", "total_cost_usd"))
    if cost is not None and 0 <= cost < 1e7:
        left.append((0, [("$%.2f" % cost, COST)]))
    right = []
    if bloom and bloom[1]:
        right.append((-1, [("%d/%d in bloom" % bloom, BLOOM)]))

    def seg_w(side):
        return sum(text_cols(t) for _, ps in side for t, _ in ps)

    def width(lft, rgt):
        return (seg_w(lft) + text_cols(SEP) * max(0, len(lft) - 1)
                + (2 if rgt else 0) + seg_w(rgt))

    while width(left, right) > tw - 1:
        cand = ([(p, 0, i) for i, (p, _) in enumerate(left)]
                + [(p, 1, i) for i, (p, _) in enumerate(right)])
        p, side, i = min(cand)
        if p >= 6:                                      # ctx is never dropped
            break
        (left if side == 0 else right).pop(i)
    return left, right, seg_w(right)


def _put_text(cv, x, y, s, fg, bg, limit):
    """Column-aware write: a wide char takes its cell plus an empty one."""
    for ch in s:
        w = char_cols(ch)
        if x + w > limit:
            return limit
        cv.put(x, y, ch, fg, bg)
        if w == 2:
            cv.put(x + 1, y, "", fg, bg)
        x += w
    return x


def draw_info(cv, y, d, pct, agents, bloom, W, pad):
    """The text row, on SOIL, from x = 1; the bloom counter flush right."""
    tw = max(10, min(W, W - pad))
    left, right, rw = info_parts(d, pct, agents, bloom, tw)
    rx = max(1, tw - rw)
    x = 1
    for n, (_, parts) in enumerate(left):
        if n:
            x = _put_text(cv, x, y, SEP, SEPC, None, rx - 2 if right else tw)
        for t, fg in parts:
            x = _put_text(cv, x, y, t, fg, None, rx - 2 if right else tw)
    x = rx
    for _, parts in right:
        for t, fg in parts:
            x = _put_text(cv, x, y, t, fg, None, tw)


# --- 256-colour fallback (STATUSLINE_NO_TRUECOLOR) ----------------------------
def _esc(t, fg=None, bg=None):
    codes = []
    if fg is not None:
        codes.append("38;5;%d" % fg)
    if bg is not None:
        codes.append("48;5;%d" % bg)
    return ("\033[%sm%s%s" % (";".join(codes), t, RESET)) if codes else t


def _capped(segs, W):
    """[(text, fg256, bg256)] -> one string, hard-capped at W columns + RESET."""
    runs = []                                           # coalesce same-colour runs:
    for t, fg, bg in segs:                              # one escape per run, not per cell
        if runs and runs[-1][1:] == [fg, bg]:
            runs[-1][0] += t
        else:
            runs.append([t, fg, bg])
    out, used = [], 0
    for t, fg, bg in runs:
        kept = []
        for ch in t:
            w = char_cols(ch)
            if used + w > W:
                break
            kept.append(ch)
            used += w
        if kept:
            out.append(_esc("".join(kept), fg, bg))
        if used >= W or len(kept) < len(t):
            break
    return "".join(out) + RESET


def plain_info(d, pct, agents, bloom, W, pad):
    """The info row in 256 colours on soil (48;5;52)."""
    tw = max(10, min(W, W - pad))
    left, right, rw = info_parts(d, pct, agents, bloom, tw)
    soil = c256(SOIL, 52)
    segs, x = [(" ", None, soil)], 1
    budget = tw - rw - 2 if right else tw
    for n, (_, parts) in enumerate(left):
        chunk = ([(SEP, SEPC)] if n else []) + parts
        cw = sum(text_cols(t) for t, _ in chunk)
        if x + cw > budget and n:
            break
        segs += [(t, c256(fg), soil) for t, fg in chunk]
        x += cw
    if right:
        segs.append((" " * max(2, tw - rw - x), None, soil))
        segs += [(t, c256(fg), soil) for _, ps in right for t, fg in ps]
        x = tw
    segs.append((" " * max(0, W - x), None, soil))
    return _capped(segs, W)


def canvas_256(cv, rows):
    """The first `rows` canvas rows in 256 colours (one escape per run)."""
    out = []
    for row in cv.cells[:rows]:
        segs = [(ch, None if fg is None else c256(fg), None if bg is None else c256(bg))
                for ch, fg, bg in row]
        out.append(_capped(segs, cv.width))
    return out


def plain(d, pct, agents, W, H, pad, now, opaque, art_w=None):
    """256-colour rows: the same heads (via canvas_256), then the info row.

    The art covers columns 0..art_w-1 (SL_BLOSSOM_BLEED=0 passes W - pad);
    the gutter beyond it stays plain, unpainted spaces, as in truecolor."""
    art_w = W if art_w is None else max(1, min(W, art_w))
    if H < 3:
        return [plain_info(d, pct, agents, bloom_count(art_w, now), W, pad)]
    cv, bloom = art_canvas(W, H, now, opaque, art_w, whole_cells=True)
    return canvas_256(cv, H - 1) + [plain_info(d, pct, agents, bloom, W, pad)]


# --- entry points ------------------------------------------------------------
def art_canvas(W, H, now, opaque, art_w, whole_cells=False):
    """(Canvas with the heads on rows 0..H-2, bloom) -- shared by both colour
    paths (whole_cells: see draw_field). A failure mid-draw wipes the art and
    returns bloom None."""
    cv = Canvas(W, H, bg=BG if opaque else None)
    if art_w < W:                                       # no-bleed: gutter stays clear
        for row in cv.cells:
            for cell in row[art_w:]:
                cell[2] = None
    cv.fill_row(H - 1, SOIL)
    bloom = None
    if H >= 2:
        try:                                            # Pixels(art_w) clips the art
            bloom = draw_field(cv, art_w, H, now, whole_cells)
        except Exception:
            if os.environ.get("SL_DEBUG"):
                raise
            bloom = None                                # half-drawn art: wipe it
            for row in cv.cells[:H - 1]:
                for x, cell in enumerate(row):
                    row[x] = [" ", None, BG if opaque and x < art_w else None]
    return cv, bloom


def build(d, W, H, now, opaque, pad=2, agents=None, art_w=None):
    """Canvas for the truecolor path (used by render, scene and the previews)."""
    pct = context_pct(d)
    art_w = W if art_w is None else max(1, min(W, art_w))
    cv, bloom = art_canvas(W, H, now, opaque, art_w)
    try:
        draw_info(cv, H - 1, d, pct, agents, bloom, W, pad)
    except Exception:
        if os.environ.get("SL_DEBUG"):
            raise
    return cv


def scene(width, height=None, t=None, d=None, opaque=False):
    """preview_png.py entry: scene(w, panel_height(lines), t) -> Canvas."""
    now = time.time() if t is None else t
    if height is None:
        height = panel_height()
    return build(d if isinstance(d, dict) else DEMO, max(1, int(width)),
                 max(1, int(height)), now, opaque)


def _bare_bg():
    """bg (xterm index) of the bare fallback lines: None on pink, SOIL on sky."""
    return c256(SOIL, 52) if BARE_ON_SOIL else None


def tiny_row(pct, W):
    """Below MIN_W columns: ` * ctx N%`, cut to W columns."""
    bg = _bare_bg()
    return _capped([(" *", 218, bg), (" ", None, bg), ("ctx", 175, bg),
                    (" ", None, bg), ("%d%%" % pct_label(pct), 222, bg)], W)


def render(d):
    # A full 1000x80 panel is ~80k cell lists; the cyclic GC would rescan them
    # several times mid-build for nothing (no cycles here). Paused, ~-35 %.
    was = gc.isenabled()
    gc.disable()
    try:
        return _render(d)
    finally:
        if was:
            gc.enable()


def _render(d):
    try:
        if not isinstance(d, dict):
            d = {}
        cols, lines = term_size()
        W = max(1, min(cols, 1000))
        pct = context_pct(d)
        if W < MIN_W:
            return [tiny_row(pct, W)]
        pad = max(0, min(env_int("STATUSLINE_RULE_PAD", 2), W // 2))
        now = time.time()
        H = panel_height(lines)
        agents = agents_of(d)
        if W < INFO_ONLY_W or H == 1:
            H = 1
        opaque = is_opaque()
        art_w = W - pad if os.environ.get("SL_BLOSSOM_BLEED", "").strip() == "0" else W
        if not truecolor():
            return plain(d, pct, agents, W, H, pad, now, opaque, art_w)
        if H == 1:
            cv = Canvas(W, 1, bg=SOIL)
            draw_info(cv, 0, d, pct, agents, bloom_count(art_w, now), W, pad)
            return cv.rows()
        return build(d, W, H, now, opaque, pad, agents, art_w).rows()
    except Exception:
        if os.environ.get("SL_DEBUG"):
            raise
        try:
            shown = pct_label(context_pct(d if isinstance(d, dict) else {}))
        except Exception:
            shown = 0
        try:
            bg = _bare_bg()
        except Exception:
            bg = None
        if bg is not None:
            return ["\033[48;5;%dm\033[38;5;218m * %s \033[38;5;175mctx "
                    "\033[38;5;225m%d%% \033[0m" % (bg, THEME, shown)]
        return ["\033[38;5;218m * blossom\033[0m \033[38;5;175mctx\033[0m "
                "\033[38;5;225m%d%%\033[0m" % shown]

