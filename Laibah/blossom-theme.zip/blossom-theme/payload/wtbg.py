#!/usr/bin/env python3
"""Windows Terminal settings helper for the blossom theme pack.

Windows Terminal has no escape sequence for the window background, so the only
way to get the dark pink sakura behind the whole window is to point the WT
profile at a background image and let WT hot-reload its settings.json. This
module does the reading, writing, backing up and restoring of that file.

    wtbg.py restore [--drop-scheme NAME]   put the profile back exactly as it was
    wtbg.py status                         report what is currently applied

Each profile's original values are saved the first time blossom is applied
to it (statusline-wt-backup.json holds one entry per profile) and replayed
verbatim on restore, including keys that were absent (they get removed again).
Restore puts back every profile blossom was applied to.
A full copy of settings.json (comments and all) is also kept next to it the
first time, as settings.json.before-blossom.bak; it is never overwritten.

Locating Windows Terminal:
  BLOSSOM_WT_SETTINGS (or SL_WT_SETTINGS)  explicit path to WT's settings.json
  BLOSSOM_GIF_DIR (or SL_WATER_GIF_DIR)    explicit dir for the background GIF
Otherwise WSL drive mounts (/mnt/<drive>/Users/*/AppData/Local/...) are
searched, or %LOCALAPPDATA% on native Windows. The GIF goes to
<that user's AppData/Local>/claude-statusline, where WT can read it.
"""

import glob
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP_FILE = os.path.join(HERE, "statusline-wt-backup.json")
APPLIED_FILE = os.path.join(HERE, "statusline-wt-applied")
BAK_SUFFIX = ".before-blossom.bak"
GIF_SUBDIR = "claude-statusline"

# Everything apply_file() may touch on the profile; restore() puts all of these
# back to their saved values (or removes them if they were absent).
MANAGED_KEYS = ("backgroundImage", "backgroundImageOpacity",
                "backgroundImageStretchMode", "backgroundImageAlignment",
                "useAcrylic", "opacity", "colorScheme")

OPACITY = 0.30
STRETCH = "fill"

_PACKAGED = ("AppData/Local/Packages/Microsoft.WindowsTerminal*/"
             "LocalState/settings.json")
_UNPACKAGED = "AppData/Local/Microsoft/Windows Terminal/settings.json"


def _env(*names):
    for name in names:
        value = os.environ.get(name, "").strip()
        if value:
            return value
    return ""


def _real_settings():
    """Newest WT settings.json on this machine, or None."""
    hits = []
    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA")
        if local:
            hits += glob.glob(os.path.join(
                local, "Packages", "Microsoft.WindowsTerminal*",
                "LocalState", "settings.json"))
            hits += glob.glob(os.path.join(
                local, "Microsoft", "Windows Terminal", "settings.json"))
    else:
        for root in ("/mnt/c/Users/*/", "/mnt/[a-z]/Users/*/"):
            hits += glob.glob(root + _PACKAGED)
            hits += glob.glob(root + _UNPACKAGED)
            if hits:
                break
    hits = sorted(set(hits), key=os.path.getmtime)
    return hits[-1] if hits else None


def settings_path():
    override = _env("BLOSSOM_WT_SETTINGS", "SL_WT_SETTINGS")
    if override:
        return override
    real = _real_settings()
    if not real:
        raise SystemExit("Windows Terminal settings.json not found "
                         "(set BLOSSOM_WT_SETTINGS to its path)")
    return real


def _local_appdata_of(path):
    """'<...>/AppData/Local' that `path` lives under, or None."""
    norm = path.replace("\\", "/")
    i = norm.lower().find("/appdata/local/")
    if i < 0:
        return None
    return path[:i + len("/AppData/Local")]


def gif_dir():
    """Where the background GIF lives: on the Windows side, so WT can read it."""
    override = _env("BLOSSOM_GIF_DIR", "SL_WATER_GIF_DIR")
    if override:
        return override
    settings = _env("BLOSSOM_WT_SETTINGS", "SL_WT_SETTINGS")
    if not settings:
        settings = _real_settings()
    local = _local_appdata_of(settings) if settings else None
    if local:
        return os.path.join(local, GIF_SUBDIR)
    raise SystemExit("cannot locate the Windows user directory for the GIF "
                     "(set BLOSSOM_GIF_DIR)")


def to_windows(p):
    """WSL path -> the Windows path WT needs; unchanged elsewhere."""
    try:
        out = subprocess.run(["wslpath", "-w", p], stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, universal_newlines=True,
                             timeout=5).stdout.strip()
        return out or p
    except Exception:
        return p


# --------------------------------------------------------------- JSON(C) ----
def _strip_jsonc(text):
    """Remove // and /* */ comments and trailing commas, outside strings."""
    out = []
    i, n = 0, len(text)
    in_str = False
    while i < n:
        ch = text[i]
        if in_str:
            out.append(ch)
            if ch == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if ch == '"':
                in_str = False
            i += 1
            continue
        if ch == '"':
            in_str = True
            out.append(ch)
            i += 1
        elif text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
        else:
            out.append(ch)
            i += 1
    text = "".join(out)
    # trailing commas: a ',' (outside strings) followed only by space and } or ]
    out = []
    in_str = False
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if in_str:
            out.append(ch)
            if ch == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if ch == '"':
                in_str = False
            i += 1
            continue
        if ch == '"':
            in_str = True
        elif ch == ",":
            j = i + 1
            while j < n and text[j] in " \t\r\n":
                j += 1
            if j < n and text[j] in "}]":
                i += 1
                continue
        out.append(ch)
        i += 1
    return "".join(out)


def load(path):
    """WT's settings.json is JSONC: comments and trailing commas are allowed."""
    with open(path, encoding="utf-8-sig") as fh:
        text = fh.read()
    try:
        return json.loads(text)
    except ValueError:
        return json.loads(_strip_jsonc(text))


def save(path, data):
    """Atomic write that keeps WT's formatting conventions (2 spaces, CRLF)."""
    path = os.path.realpath(path)
    text = json.dumps(data, indent=2, ensure_ascii=False)
    text = text.replace("\n", "\r\n") + "\r\n"
    tmp = path + ".blossom-tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)
    os.replace(tmp, path)


def profile_list(data):
    """The profiles list, in either the modern {"list": [...]} or legacy [...] form."""
    p = data.get("profiles")
    if isinstance(p, dict):
        return p.get("list") or []
    return p if isinstance(p, list) else []


def _same_guid(a, b):
    return isinstance(a, str) and isinstance(b, str) and a.strip().lower() == b.strip().lower()


def target_profile(data):
    """The profile this session is running in (WT_PROFILE_ID), else the
    default profile, else the first one."""
    profiles = [p for p in profile_list(data) if isinstance(p, dict)]
    for guid in (os.environ.get("WT_PROFILE_ID"), data.get("defaultProfile")):
        if not guid:
            continue
        for p in profiles:
            if _same_guid(p.get("guid"), guid):
                return p
    return profiles[0] if profiles else None


def snapshot(profile):
    return {k: profile[k] for k in MANAGED_KEYS if k in profile}


def profile_key(profile):
    """How a profile is identified in the backup: its guid, else its name."""
    guid = profile.get("guid")
    if isinstance(guid, str) and guid.strip():
        return guid.strip().lower()
    return "name:%s" % profile.get("name")


def _find_profile(data, key):
    for p in profile_list(data):
        if isinstance(p, dict) and profile_key(p) == key:
            return p
    return None


def load_backup():
    """{profile key: saved values} from BACKUP_FILE ({} if there is none).
    Also reads the older single-profile form {"guid": ..., "values": ...}."""
    try:
        with open(BACKUP_FILE, encoding="utf-8") as fh:
            saved = json.load(fh)
    except OSError:
        return {}
    if isinstance(saved, dict) and isinstance(saved.get("profiles"), dict):
        return dict(saved["profiles"])
    if isinstance(saved, dict) and "values" in saved:
        guid = saved.get("guid")
        key = guid.strip().lower() if isinstance(guid, str) and guid.strip() else "name:None"
        return {key: saved.get("values") or {}}
    raise ValueError("unrecognised backup file %s" % BACKUP_FILE)


def _backup_had_schemes():
    """Whether WT's settings.json had a "schemes" key before blossom first
    touched it: True/False, or None when unknown (older backup, or none)."""
    try:
        with open(BACKUP_FILE, encoding="utf-8") as fh:
            saved = json.load(fh)
    except (OSError, ValueError):
        return None
    value = saved.get("had_schemes") if isinstance(saved, dict) else None
    return value if isinstance(value, bool) else None


def write_backup(entries, had_schemes=None):
    """Write the backup. `had_schemes` is recorded when the backup is first
    created; later writes keep whatever the file already says."""
    if had_schemes is None:
        had_schemes = _backup_had_schemes()
    doc = {"version": 2, "profiles": entries}
    if had_schemes is not None:
        doc["had_schemes"] = had_schemes
    tmp = BACKUP_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    os.replace(tmp, BACKUP_FILE)


def backed_up(profile):
    """True when `profile`'s original values are in the backup."""
    try:
        return profile is not None and profile_key(profile) in load_backup()
    except ValueError:
        return False


def ensure_scheme(data, scheme):
    """Add or update a colour scheme in place, matched by name."""
    schemes = data.setdefault("schemes", [])
    for i, s in enumerate(schemes):
        if s.get("name") == scheme["name"]:
            schemes[i] = scheme
            return
    schemes.append(scheme)


def apply_file(image, opacity=None, scheme=None):
    """Point the profile at `image` (and colour scheme `scheme`, if given)."""
    path = settings_path()
    data = load(path)
    profile = target_profile(data)
    if profile is None:
        raise SystemExit("no Windows Terminal profile to update")
    if not os.path.exists(image):
        raise SystemExit("missing %s - build it first" % image)

    # Back up this profile's original values the first time it is touched,
    # BEFORE writing (so a crash can never lose them). Profiles applied earlier
    # keep their entries; restore() replays them all.
    had_backup_file = os.path.exists(BACKUP_FILE)
    entries = load_backup()
    key = profile_key(profile)
    added = key not in entries
    if added:
        if not os.path.exists(path + BAK_SUFFIX):       # keep the very first copy
            shutil.copy2(path, path + BAK_SUFFIX)
        entries[key] = snapshot(profile)
        # On the first apply, also note whether "schemes" existed, so restore
        # can remove the key again if blossom was what created it.
        write_backup(entries, None if had_backup_file else ("schemes" in data))

    profile["backgroundImage"] = to_windows(image)
    profile["backgroundImageOpacity"] = OPACITY if opacity is None else opacity
    profile["backgroundImageStretchMode"] = STRETCH
    # Acrylic composites the desktop over the image and washes it out.
    profile["useAcrylic"] = False
    profile["opacity"] = 100
    if scheme:
        ensure_scheme(data, scheme)
        profile["colorScheme"] = scheme["name"]

    try:
        save(path, data)
    except BaseException:
        # nothing was written: forget the entry we just added
        if added:
            entries.pop(key, None)
            if entries or had_backup_file:
                write_backup(entries)
            elif os.path.exists(BACKUP_FILE):
                os.remove(BACKUP_FILE)
        raise
    # blossom.py reads this marker to know the GIF really is behind the panel.
    with open(APPLIED_FILE, "w", encoding="utf-8") as fh:
        fh.write(os.path.basename(image) + "\n")
    return image


def _scheme_in_use(data, name):
    p = data.get("profiles")
    defaults = p.get("defaults") if isinstance(p, dict) else None
    for prof in profile_list(data) + ([defaults] if isinstance(defaults, dict) else []):
        if not isinstance(prof, dict):
            continue
        cs = prof.get("colorScheme")
        if cs == name or (isinstance(cs, dict) and name in cs.values()):
            return True
    return False


def drop_scheme(name, data=None, path=None, had_schemes=None):
    """Remove scheme `name` from WT if no profile uses it. True if removed.
    When that leaves the list empty and `had_schemes` is False (settings.json
    had no "schemes" key before blossom), the key is removed too."""
    own = data is None
    if own:
        path = settings_path()
        data = load(path)
    schemes = data.get("schemes") or []
    keep = [s for s in schemes if not (isinstance(s, dict) and s.get("name") == name)]
    if len(keep) == len(schemes) or _scheme_in_use(data, name):
        return False
    if not keep and had_schemes is False:
        data.pop("schemes", None)
    else:
        data["schemes"] = keep
    if own:
        save(path, data)
    return True


def restore(drop=None):
    """Put back every profile blossom was applied to. Returns False when there
    was nothing to restore."""
    if not os.path.exists(BACKUP_FILE):
        return False
    path = settings_path()
    data = load(path)
    entries = load_backup()
    had_schemes = _backup_had_schemes()

    for key, values in entries.items():
        profile = _find_profile(data, key)
        if profile is None:                   # the profile was deleted since
            continue
        for k in MANAGED_KEYS:
            profile.pop(k, None)
        profile.update(values or {})
    if drop:
        drop_scheme(drop, data, had_schemes=had_schemes)
    save(path, data)

    os.remove(BACKUP_FILE)
    if os.path.exists(APPLIED_FILE):
        os.remove(APPLIED_FILE)
    return True


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "status"
    if cmd == "restore":
        drop = None
        if "--drop-scheme" in args:
            i = args.index("--drop-scheme")
            drop = args[i + 1] if i + 1 < len(args) else None
        print("Windows Terminal profile restored" if restore(drop)
              else "nothing to restore")
    elif cmd == "status":
        try:
            print("settings : %s" % settings_path())
            print("gif dir  : %s" % gif_dir())
        except SystemExit as exc:
            print("settings : not found (%s)" % exc)
        try:
            with open(APPLIED_FILE, encoding="utf-8") as fh:
                applied = fh.read().strip() or "none"
        except OSError:
            applied = "none"
        print("applied  : %s" % applied)
        print("backup   : %s" % ("present" if os.path.exists(BACKUP_FILE) else "none"))
    else:
        sys.stderr.write("usage: wtbg.py restore [--drop-scheme NAME] | status\n")
        sys.exit(2)


if __name__ == "__main__":
    main()
