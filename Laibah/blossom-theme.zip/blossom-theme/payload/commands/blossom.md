---
allowed-tools: Bash(__BLOSSOM_DIR__/blossomctl.sh:*)
argument-hint: "[rows|full|auto | wt on|off | status]"
description: Blossom status line settings (panel height, Windows Terminal background)
---
<!-- installed by blossom-theme; uninstall.sh removes this file -->

!`__BLOSSOM_CTL__ "$ARGUMENTS"`

Relay the output above to the user in one short line. If the height changed,
mention that it appears on the next status line refresh (within a second).
Do not call any tools.
