#!/usr/bin/env python3
"""Claude Code status line: theme dispatcher for the "blossom" theme pack.

Reads the status line JSON on stdin (see https://code.claude.com/docs/en/statusline)
and hands it to the theme named in <this dir>/statusline-theme. Themes live in
<this dir>/statuslines/<name>.py and expose `render(data) -> list[str]`.

This pack ships one theme, "blossom", so that is also the default. Pure stdlib.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
THEMES_DIR = os.path.join(HERE, "statuslines")
STATE_FILE = os.path.join(HERE, "statusline-theme")
DEFAULT_THEME = "blossom"

sys.path.insert(0, THEMES_DIR)


def is_theme(name):
    """A theme declares a DESCRIPTION; everything else in there is a helper."""
    try:
        with open(os.path.join(THEMES_DIR, name + ".py"),
                  encoding="utf-8", errors="replace") as fh:
            return "\nDESCRIPTION = " in fh.read(65536)
    except (OSError, ValueError):
        return False


def available():
    try:
        names = sorted(f[:-3] for f in os.listdir(THEMES_DIR)
                       if f.endswith(".py") and f != "__init__.py")
    except OSError:
        return []
    return [name for name in names if is_theme(name)]


def active():
    name = os.environ.get("SL_THEME", "").strip()
    if not name:
        try:
            with open(STATE_FILE, encoding="utf-8", errors="replace") as fh:
                name = fh.read().strip()
        except (OSError, ValueError):
            name = ""
    if name not in available():
        name = DEFAULT_THEME
    return name


def main():
    # Native Windows Python writes cp1252 and CRLF to a pipe; the panel is
    # UTF-8 half blocks, one row per "\n".
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace", newline="\n")
    except Exception:
        pass
    try:
        data = json.loads(sys.stdin.buffer.read().decode("utf-8", "replace"))
    except Exception:
        data = {}

    name = active()
    try:
        theme = __import__(name)
        rows = theme.render(data)
    except Exception as exc:  # never blank the status line on a theme bug
        if os.environ.get("SL_DEBUG"):
            raise
        rows = ["\033[38;5;167mstatus line theme '%s' failed: %s: %s\033[0m"
                % (name, type(exc).__name__, exc)]

    print("\n".join(str(r) for r in rows))


if __name__ == "__main__":
    main()
