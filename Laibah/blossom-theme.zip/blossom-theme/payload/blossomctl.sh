#!/bin/sh
# Backs the /blossom slash command. The installer fills in the interpreter.
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PY="__PYTHON__" PYARG=
if [ ! -x "$PY" ]; then
    PY=
    for c in python3 python py; do
        command -v "$c" >/dev/null 2>&1 || continue
        a=; [ "$c" = py ] && a=-3
        if "$c" ${a:+"$a"} -c 'import sys; sys.exit(sys.version_info < (3, 7))' >/dev/null 2>&1; then
            PY=$c PYARG=$a; break
        fi
    done
    [ -n "$PY" ] || { echo "Python 3.7 or newer not found" >&2; exit 1; }
fi
exec "$PY" ${PYARG:+"$PYARG"} "$DIR/blossomctl.py" "$@"
