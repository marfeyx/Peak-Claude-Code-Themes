#!/usr/bin/env python3
"""Controller behind the /blossom slash command.

    blossomctl.py                    show the current settings
    blossomctl.py status             same
    blossomctl.py <rows|full|auto>   panel height: a row count (1-99; 1-2 = info row only), the
                                     whole terminal, or automatic
    blossomctl.py wt on              Windows Terminal: pink sakura background
                                     and the Blossom colour scheme
    blossomctl.py wt off             Windows Terminal: put the profile back
    blossomctl.py help

The slash command passes every argument as one string; it is split here.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
HEIGHT_FILE = os.path.join(HERE, "statusline-blossom-height")
WT_SCRIPT = os.path.join(HERE, "sl-blossom-wt.py")
WTBG = os.path.join(HERE, "wtbg.py")
BACKUP = os.path.join(HERE, "statusline-wt-backup.json")
# another theme installed straight into the config dir keeps its WT backup here
FOREIGN_BACKUP = os.path.join(os.path.dirname(HERE), "statusline-wt-backup.json")


def run(script, *args):
    """(exit code, stdout, stderr) of `python <script> args`."""
    try:
        p = subprocess.run([sys.executable, script] + list(args),
                           stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, universal_newlines=True,
                           timeout=180)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except Exception as exc:
        return 1, "", str(exc)


def last_line(text):
    lines = [l for l in (text or "").splitlines() if l.strip()]
    return lines[-1].strip() if lines else ""


def in_wt():
    return bool(os.environ.get("WT_SESSION")
                or os.environ.get("BLOSSOM_WT_SETTINGS"))


def height():
    try:
        with open(HEIGHT_FILE, encoding="utf-8") as fh:
            return fh.read().strip() or "auto"
    except OSError:
        return "auto"


def status():
    print("Blossom status line: panel height %s." % height())
    if os.path.exists(BACKUP):
        print("Windows Terminal background: on (/blossom wt off to remove).")
    elif in_wt():
        print("Windows Terminal background: off (/blossom wt on to enable).")
    else:
        print("Windows Terminal background: not available here (not running in Windows Terminal).")
    print("Usage: /blossom <rows|full|auto> | wt on | wt off | status")


def set_height(value):
    ok = value in ("full", "auto") or (value.isdigit() and 1 <= int(value) <= 99)
    if not ok:
        print('Ignoring height "%s": use a row count (1-99), "full" or "auto".' % value)
        return 1
    with open(HEIGHT_FILE, "w", encoding="utf-8") as fh:
        fh.write(value + "\n")
    print("Blossom panel height set to %s (shows on the next refresh)." % value)
    return 0


def wt_on():
    if not in_wt():
        print("Not running in Windows Terminal, so there is no background to set. "
              "The status line itself works everywhere.")
        return 0
    if os.path.exists(FOREIGN_BACKUP) and not os.path.exists(BACKUP):
        print("Another status line theme's Windows Terminal background is active "
              "(%s exists). Switch that theme off first, then run /blossom wt on."
              % FOREIGN_BACKUP)
        return 1
    rc, img, err = run(WT_SCRIPT, "path")
    if rc != 0:
        print("Could not locate Windows Terminal: %s" % (last_line(err) or "unknown error"))
        return 1
    if not os.path.exists(img):
        print("Rendering the blossom background (one-off, a few seconds)...")
        rc, _out, err = run(WT_SCRIPT, "build")
        if rc != 0:
            print("Blossom background render failed: %s" % last_line(err))
            return 1
    rc, out, err = run(WT_SCRIPT, "apply")
    if rc == 0:
        print("Blossom background and colour scheme enabled in Windows Terminal.")
        return 0
    if rc == 4:
        print(last_line(err))
        return 1
    # wtbg.apply_file writes settings.json atomically and drops its own backup
    # entry when the write fails, so nothing is half-applied here. (No restore:
    # that would also undo blossom on profiles where it is working.)
    why = last_line(err) or last_line(out)
    print("Could not set the blossom background (%s); the status line still works." % why)
    return 1


def wt_off():
    rc, out, err = run(WTBG, "restore", "--drop-scheme", "Blossom")
    if rc != 0:
        print("Could not restore Windows Terminal: %s" % (last_line(err) or last_line(out)))
        return 1
    if "restored" in out:
        print("Windows Terminal background removed; every profile it was on is back as it was.")
    else:
        print("Nothing to undo: the blossom background was not applied.")
    return 0


def main():
    words = " ".join(sys.argv[1:]).split()
    if not words or words[0] == "status":
        status()
        return 0
    head = words[0].lower()
    if head in ("help", "-h", "--help"):
        print(__doc__.strip())
        return 0
    if head == "wt":
        sub = words[1].lower() if len(words) > 1 else ""
        if sub == "on":
            return wt_on()
        if sub == "off":
            return wt_off()
        print("Usage: /blossom wt on | wt off")
        return 1
    return set_height(head)


if __name__ == "__main__":
    sys.exit(main())
