#!/usr/bin/env python3
"""Windows Terminal side of the "blossom" theme: background GIF and scheme.

    sl-blossom-wt.py build [--force]   render the animated sakura GIF
    sl-blossom-wt.py apply [--force]   point the WT profile at it, with the Blossom scheme
    sl-blossom-wt.py status            report what is built and applied
    sl-blossom-wt.py path              print where the GIF lives

The art itself lives in statuslines/blossomgif.py and every colour in
statuslines/blossompal.py, the one palette the panel, this background and the
Claude Code UI theme all share. The GIF's bottom 60 % is flat BP.BG, the exact
colour of the scheme background and of the status line panel, so the flower
bed below always sits on the colour it was designed against.

There is no restore command here: `wtbg.py restore` (which `/blossom wt off`
and the uninstaller call) puts the profile back from the one-time backup.

Exit status of `apply`: 0 applied (or already applied), 2 usage, 4 another
theme's background is active, anything else (1) a failure.

Every write to Windows Terminal's settings.json goes through wtbg.apply_file,
so the backup, the managed key set and the atomic CRLF write are shared with
restore. Applying from a second WT profile adds that profile to the backup;
restore puts back every profile. This script never runs inside a status line
frame.

Leaving blossom puts the profile back but leaves the unused "Blossom" entry in
WT's schemes list unless `--drop-scheme Blossom` is passed to the restore (the
uninstaller does). Older blossom-bg-v*.gif files are listed by `status`.
"""

import glob
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.dirname(HERE)          # the Claude config dir (~/.claude)
EXIT_FOREIGN = 4

sys.path.insert(0, os.path.join(HERE, "statuslines"))

import blossomgif         # noqa: E402  (needs the path above)
import blossompal         # noqa: E402


def _load(name, path):
    import importlib.util
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


wtbg = _load("blossom_wtbg", os.path.join(HERE, "wtbg.py"))

# WT caches background images by URI, so a change to the art needs a new name:
# the name carries blossomgif.REVISION ("blossom-bg-v<REVISION>.gif").
IMAGE_NAME = blossomgif.FILE
OPACITY = 1.0             # the dark pink is baked into the GIF itself
SCHEME = blossompal.SCHEME
THEME = "blossom"
# Every GIF this install renders is listed here, so uninstall removes exactly those.
BUILT_LIST = os.path.join(HERE, "statusline-wt-gifs.txt")

# Other status line themes installed straight into ~/.claude keep their own WT
# backup there. While one exists, that theme owns the background: taking a
# backup now would record its image as the "original".
FOREIGN_BACKUP = os.path.join(CONFIG_DIR, "statusline-wt-backup.json")


def foreign_owner():
    return (os.path.exists(FOREIGN_BACKUP)
            and os.path.abspath(FOREIGN_BACKUP) != os.path.abspath(wtbg.BACKUP_FILE)
            and not os.path.exists(wtbg.BACKUP_FILE))


# ----------------------------------------------------------------- build ----
def image_path():
    return os.path.join(wtbg.gif_dir(), IMAGE_NAME)


def build(path=None):
    """Render the GIF (atomic and verified inside blossomgif.build)."""
    path = path or image_path()
    try:
        blossomgif.build(path, "pink")
    except Exception as exc:
        raise SystemExit("blossom background build failed: %s" % exc)
    try:
        with open(BUILT_LIST, encoding="utf-8") as fh:
            known = fh.read().splitlines()
    except OSError:
        known = []
    if path not in known:
        with open(BUILT_LIST, "a", encoding="utf-8") as fh:
            fh.write(path + "\n")
    return path


# ----------------------------------------------------------------- apply ----
def is_applied(image, need_backup=False):
    """True when the profile already holds every value apply_file would write
    (and, with need_backup, its original values are in the backup)."""
    try:
        data = wtbg.load(wtbg.settings_path())
    except (OSError, ValueError, SystemExit):
        return False
    profile = wtbg.target_profile(data)
    if profile is None:
        return False
    if need_backup and not wtbg.backed_up(profile):
        return False
    scheme = next((s for s in data.get("schemes") or []
                   if isinstance(s, dict) and s.get("name") == SCHEME["name"]), None)
    return (profile.get("backgroundImage") == wtbg.to_windows(image)
            and profile.get("colorScheme") == SCHEME["name"]
            and profile.get("backgroundImageOpacity") == OPACITY
            and profile.get("backgroundImageStretchMode") == wtbg.STRETCH
            and profile.get("useAcrylic") is False
            and profile.get("opacity") == 100
            and scheme == SCHEME)


def apply(force=False):
    image = image_path()
    if not os.path.exists(image):
        build(image)
    # Skip the write when nothing would change: WT reloads on every write.
    # This profile must be in the backup, or a skipped apply would leave
    # nothing to restore it from.
    if not force and is_applied(image, need_backup=True):
        return image, False
    wtbg.apply_file(image, OPACITY, SCHEME)
    return image, True


def status():
    try:
        settings = wtbg.settings_path()
        image = image_path()
    except SystemExit as exc:
        print("settings : not found (%s)" % exc)
        print("backup   : %s" % ("present" if os.path.exists(wtbg.BACKUP_FILE) else "none"))
        return
    print("settings : %s%s" % (settings, "" if os.path.exists(settings) else " (missing)"))
    if os.path.exists(image):
        print("image    : %s (built, %d KB)" % (image, os.path.getsize(image) // 1024))
    else:
        print("image    : %s (missing)" % image)
    print("applied  : %s" % ("yes" if os.path.exists(image) and is_applied(image) else "no"))
    print("backup   : %s" % ("present" if os.path.exists(wtbg.BACKUP_FILE) else "none"))
    if foreign_owner():
        print("note     : another theme's background backup exists (%s)" % FOREIGN_BACKUP)
    stale = sorted(os.path.basename(p) for p in
                   glob.glob(os.path.join(os.path.dirname(image), THEME + "-bg-v*.gif"))
                   if os.path.basename(p) != IMAGE_NAME)
    print("stale    : %s" % (", ".join(stale) if stale else "none"))


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "status"
    if cmd == "build":
        path = image_path()
        if os.path.exists(path) and "--force" not in args:
            print("up to date: %s (%d KB; --force to rebuild)"
                  % (path, os.path.getsize(path) // 1024))
            return
        t0 = time.time()
        build(path)
        print("built %s (%d KB, %.1f s)" % (path, os.path.getsize(path) // 1024,
                                            time.time() - t0))
    elif cmd == "apply":
        if foreign_owner():
            sys.stderr.write(
                "another status line theme's Windows Terminal background is active "
                "(%s exists); switch that theme off first, then try again\n" % FOREIGN_BACKUP)
            sys.exit(EXIT_FOREIGN)
        image, wrote = apply(force="--force" in args)
        print("background -> %s, scheme -> %s%s"
              % (os.path.basename(image), SCHEME["name"],
                 "" if wrote else " (already applied)"))
    elif cmd == "path":
        print(image_path())
    elif cmd == "status":
        status()
    else:
        sys.stderr.write("usage: sl-blossom-wt.py [build [--force] | apply [--force]"
                         " | status | path]\nunknown command: %s\n" % cmd)
        sys.exit(2)


if __name__ == "__main__":
    main()
