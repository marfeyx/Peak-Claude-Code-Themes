#!/bin/sh
# Remove the blossom status line theme and put your previous settings back.
#   sh uninstall.sh [--force]
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# First of python3 / python / py -3 that really is Python 3.7+.
PY= PYARG=
for c in python3 python py; do
    command -v "$c" >/dev/null 2>&1 || continue
    a=; [ "$c" = py ] && a=-3
    if "$c" ${a:+"$a"} -c 'import sys; sys.exit(sys.version_info < (3, 7))' >/dev/null 2>&1; then
        PY=$c PYARG=$a; break
    fi
done
[ -n "$PY" ] || { echo "Python 3.7 or newer not found" >&2; exit 1; }
if [ -f "$here/uninstall.py" ]; then
    exec "$PY" ${PYARG:+"$PYARG"} "$here/uninstall.py" "$@"
else
    exec "$PY" ${PYARG:+"$PYARG"} "$here/payload/uninstall.py" "$@"
fi
