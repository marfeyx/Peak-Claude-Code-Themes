#!/usr/bin/env python3
"""Uninstaller for the blossom Claude Code status line theme (run via uninstall.sh).

In this order:
  1. Windows Terminal: put the profile back from the backup taken on the first
     apply, and remove the unused "Blossom" colour scheme.
  2. Delete the background GIF(s) this install generated.
  3. settings.json: restore the statusLine, theme and env.COLORTERM values that
     were there before the install -- but only where they still hold what the
     installer wrote. Anything you changed since is left alone.
  4. Remove themes/blossom.json and commands/blossom.md if they are ours (and
     put back the ones the installer backed up, if any).
  5. Move the backups out to <config dir>/blossom-theme-backups-<time>/ and
     delete <config dir>/blossom-theme/.

    uninstall.sh            do it
    uninstall.sh --force    carry on even if Windows Terminal cannot be restored
"""
import json
import os
import shutil
import sys
import time

MARKER = "installed by blossom-theme"
UI_THEME = "custom:blossom"
HERE = os.path.dirname(os.path.abspath(__file__))


def say(msg=""):
    print(msg, flush=True)


def read_text(path):
    with open(path, encoding="utf-8-sig") as fh:
        return fh.read()


def write_atomic(path, text):
    path = os.path.realpath(path)
    tmp = "%s.blossom-tmp.%d" % (path, os.getpid())
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    if os.path.exists(path):
        os.chmod(tmp, os.stat(path).st_mode & 0o7777)   # keep e.g. 0600
    os.replace(tmp, path)


def original_bytes(settings, state):
    """The pre-install settings.json bytes, if settings now matches them
    exactly, so its own formatting comes back too; else None."""
    b = state.get("settings_backup")
    if not b or not os.path.isfile(b):
        return None
    try:
        text = read_text(b)
        orig = json.loads(text) if text.strip() else {}
        # compare serialised: dict == ignores key order and 1 == 1.0 == True
        if json.dumps(orig, ensure_ascii=False) != json.dumps(settings, ensure_ascii=False):
            return None
        with open(b, "rb") as fh:
            return fh.read()
    except (OSError, ValueError, UnicodeDecodeError):
        return None


def load_module(name, path):
    import importlib.util
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    force = "--force" in sys.argv[1:]
    if os.path.basename(HERE) == "blossom-theme" and \
            os.path.exists(os.path.join(HERE, "install-state.json")):
        # run from the install dir itself: that is the install to remove,
        # whatever CLAUDE_CONFIG_DIR says (or doesn't) in this shell
        cfg = os.path.dirname(HERE)
    else:
        cfg = os.path.abspath(os.path.expanduser(
            os.environ.get("CLAUDE_CONFIG_DIR") or os.path.join("~", ".claude")))
    dest = os.path.join(cfg, "blossom-theme")
    if not os.path.isdir(dest):
        say("blossom is not installed in %s - nothing to do." % cfg)
        return 0
    say("Uninstalling the blossom status line from %s" % dest)

    try:
        with open(os.path.join(dest, "install-state.json"), encoding="utf-8") as fh:
            state = json.load(fh)
    except (OSError, ValueError):
        state = {}
        say("  note: install-state.json is missing; only blossom's own entries are removed")

    # 1 + 2. Windows Terminal
    wt_backup = os.path.join(dest, "statusline-wt-backup.json")
    wtbg = None
    wt_restored = False
    try:
        wtbg = load_module("blossom_wtbg", os.path.join(dest, "wtbg.py"))
    except Exception as exc:
        say("  could not load wtbg.py (%s)" % exc)
    if os.path.exists(wt_backup):
        try:
            if wtbg is None:
                raise RuntimeError("wtbg.py missing")
            wtbg.restore(drop="Blossom")
            wt_restored = True
            say("  Windows Terminal profile(s) restored")
        except BaseException as exc:          # SystemExit from settings lookup too
            say("  could not restore Windows Terminal: %s" % exc)
            if not force:
                say("Stopped; nothing else was changed. Fix the above, or run "
                    "uninstall.sh --force to skip Windows Terminal.\n"
                    "(The profile backup is %s)" % wt_backup)
                return 1
    # only the GIFs this install rendered (sl-blossom-wt.py lists them)
    try:
        with open(os.path.join(dest, "statusline-wt-gifs.txt"), encoding="utf-8") as fh:
            built = [l.strip() for l in fh if l.strip()]
    except OSError:
        built = []
    for gif in built:
        if os.path.basename(gif).startswith("blossom-bg-v") and gif.endswith(".gif") \
                and os.path.isfile(gif):
            try:
                os.remove(gif)
                say("  removed %s" % gif)
            except OSError as exc:
                say("  could not remove %s (%s); delete it by hand later" % (gif, exc))
    for folder in sorted({os.path.dirname(g) for g in built}):
        try:
            os.rmdir(folder)                   # only succeeds if now empty
        except OSError:
            pass

    # 3. settings.json
    settings_file = os.path.join(cfg, "settings.json")
    backups = os.path.join(dest, "backups")
    os.makedirs(backups, exist_ok=True)
    if os.path.exists(settings_file):
        try:
            text = read_text(settings_file)
            settings = json.loads(text) if text.strip() else {}
        except (OSError, ValueError, UnicodeDecodeError) as exc:
            settings = None
            say("  settings.json is not readable JSON (%s); left alone. Remove the "
                "statusLine entry by hand." % exc)
        if isinstance(settings, dict):
            before = json.dumps(settings, indent=2, ensure_ascii=False) + "\n"
            sl = settings.get("statusLine")
            script = os.path.join(dest, "statusline.py")
            if isinstance(sl, dict) and (sl.get("command") == state.get("our_command")
                                         or script in str(sl.get("command", ""))):
                if state.get("had_statusLine"):
                    settings["statusLine"] = state.get("statusLine")
                else:
                    settings.pop("statusLine", None)
            elif sl is not None:
                say("  statusLine was changed after the install; left as it is")
            if settings.get("theme") == UI_THEME and (state.get("set_theme") or not state):
                if state.get("had_theme"):
                    settings["theme"] = state.get("theme")
                else:
                    settings.pop("theme", None)
            env = settings.get("env")
            if state.get("added_colorterm") and isinstance(env, dict) \
                    and env.get("COLORTERM") == "truecolor":
                env.pop("COLORTERM", None)
                if not env and state.get("created_env"):
                    settings.pop("env", None)
            after = json.dumps(settings, indent=2, ensure_ascii=False) + "\n"
            if after != before:
                shutil.copy2(settings_file, os.path.join(
                    backups, "settings.json.before-uninstall.%s" % time.strftime("%Y%m%d-%H%M%S")))
                if not settings and not state.get("settings_existed", True):
                    os.remove(settings_file)
                    say("  settings.json removed (it did not exist before the install)")
                else:
                    raw = original_bytes(settings, state)
                    if raw is not None:
                        real = os.path.realpath(settings_file)
                        tmp = "%s.blossom-tmp.%d" % (real, os.getpid())
                        with open(tmp, "wb") as fh:
                            fh.write(raw)
                        os.chmod(tmp, os.stat(real).st_mode & 0o7777)
                        os.replace(tmp, real)
                    else:
                        write_atomic(settings_file, after)
                    say("  settings.json restored")

    # 4. UI theme file and slash command
    ours_theme = os.path.join(dest, "themes", "blossom.json")
    cc_theme = os.path.join(cfg, "themes", "blossom.json")
    tb = state.get("themes_backup")
    # A themes/blossom.json that was there before the install is kept: as it
    # was if it matched the shipped one, else from the backup below. Without
    # install-state.json, ours is removed only if the content is ours.
    keep_theme_file = bool(state.get("had_theme_file")) and not tb
    try:
        if not keep_theme_file and os.path.exists(cc_theme) and \
                read_text(cc_theme).replace("\r\n", "\n") == \
                read_text(ours_theme).replace("\r\n", "\n"):
            os.remove(cc_theme)
            say("  removed themes/blossom.json")
        elif keep_theme_file:
            say("  kept themes/blossom.json (it was there before the install)")
    except OSError:
        pass
    if tb and os.path.exists(tb) and not os.path.exists(cc_theme):
        shutil.copy2(tb, cc_theme)
        say("  put back your previous themes/blossom.json")

    cmd_file = os.path.join(cfg, "commands", "blossom.md")
    try:
        if os.path.exists(cmd_file) and MARKER in read_text(cmd_file):
            os.remove(cmd_file)
            say("  removed commands/blossom.md (/blossom)")
    except OSError:
        pass
    cb = state.get("command_backup")
    if cb and os.path.exists(cb) and not os.path.exists(cmd_file):
        shutil.copy2(cb, cmd_file)
        say("  put back your previous commands/blossom.md")

    for d in state.get("created_dirs") or []:
        try:
            os.rmdir(d)                       # only if still empty
        except OSError:
            pass

    # 5. keep the backups, remove the rest
    kept = None
    if os.path.isdir(backups) and os.listdir(backups):
        kept = os.path.join(cfg, "blossom-theme-backups-%s" % time.strftime("%Y%m%d-%H%M%S"))
        shutil.move(backups, kept)
    shutil.rmtree(dest, ignore_errors=True)
    say("  removed %s" % dest)
    if kept:
        say("  your settings backups are in %s (safe to delete)" % kept)
    say("")
    say("Done. Restart Claude Code.")
    if wt_restored:
        say("(Windows Terminal keeps a full copy of its settings from before the first\n"
            " apply as settings.json%s next to its settings.json; delete it if you like.)"
            % getattr(wtbg, "BAK_SUFFIX", ".bak"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
