# Blossom: a cherry-blossom status line for Claude Code

Blossom turns the Claude Code status line into a row of big pixel-art cherry
blossoms. Each flower slowly opens and closes on its own clock, green sakura
leaves fan out behind them, little yellow twinkles sparkle around the open
ones, and an info row underneath shows the model, folder, git branch, context
use and cost (plus a count of running subagents while Claude has any).

If you use **Windows Terminal**, it can also give the whole window an animated
dark-pink background with a sakura branch and falling petals, plus a matching
colour scheme. That part is optional. The status line works on its own in any
terminal that supports truecolor.

It also comes with a matching Claude Code UI theme (`custom:blossom`), so
Claude Code's own text colours suit the pink.

Everything is plain Python 3 standard library: no pip, no node, no jq.

---

## Requirements

- **Claude Code**, a recent version. The animation needs
  `statusLine.refreshInterval`, and the UI theme needs custom themes
  (`~/.claude/themes/`).
- **Python 3.7 or newer**, available as `python3` (or `python`, or `py -3`).
  The scripts pick the first one that really is Python 3.7+.
  - macOS: run `xcode-select --install` if `python3` is missing.
  - Windows: use WSL (recommended), or Git Bash with python.org's Python.
- **A truecolor terminal**: Windows Terminal, iTerm2, WezTerm, kitty,
  Alacritty, GNOME Terminal, VS Code's terminal and others all work.
  - Claude Code only shows 24-bit colour when `COLORTERM=truecolor` is set in
    the environment it **starts** in. Windows Terminal does not pass it on to
    WSL, so add this to your `~/.bashrc` or `~/.zshrc`:

    ```sh
    export COLORTERM=truecolor
    ```

    The installer also adds `"COLORTERM": "truecolor"` to the `env` block of
    `settings.json`.
  - If your terminal has no 24-bit colour (for example, the old macOS
    Terminal.app), set `STATUSLINE_NO_TRUECOLOR=1`. You then get a 256-colour
    version.
- **A font with block characters** (`▀ ▄`), such as Cascadia Code, Menlo, JetBrains
  Mono or DejaVu Sans Mono. Set the line spacing to 1.0, and set
  "ambiguous-width characters" to **narrow** (single width).
- **Windows Terminal (optional)**, for the pink window background and colour
  scheme. Only Windows Terminal + WSL is supported for this part.

## Install

1. Unzip the archive, open a terminal and go into the folder:

   ```sh
   unzip blossom-theme.zip
   cd blossom-theme
   ```

   No `unzip` command (a fresh Ubuntu/WSL doesn't have one)? Use either of these:

   - `python3 -m zipfile -e blossom-theme.zip .` and then `cd blossom-theme`
   - `sudo apt install unzip`, then the commands above

   You can also extract it in Windows Explorer and then, in WSL, go to the
   folder that contains `install.sh`. Explorer's "Extract All" puts it one
   level deeper than you might expect, for example
   `cd /mnt/c/Users/<you>/Downloads/blossom-theme/blossom-theme`. File
   permissions don't matter, because the installer sets them.

2. Run the installer:

   ```sh
   sh install.sh
   ```

   If you are inside Windows Terminal, it asks whether to set the pink
   background as well. Your profile is backed up first.

3. **Restart Claude Code.** The flowers appear at the bottom.

Installer options:

| option | what it does |
|---|---|
| `--yes` | don't ask, answer yes to everything |
| `--wt` / `--no-wt` | set / don't touch the Windows Terminal background |
| `--no-ui-theme` | leave Claude Code's own UI theme as it is |
| `--height 12` | panel height in rows (or `full` / `auto`) |

### What the installer changes

The files go into one folder, `~/.claude/blossom-theme/`. If you set
`CLAUDE_CONFIG_DIR`, it uses that folder instead of `~/.claude`. Outside that
folder it touches only these:

- `~/.claude/settings.json`: it sets `statusLine` to blossom and `theme` to
  `custom:blossom`, and adds `env.COLORTERM`. Your other settings stay as they
  are. It saves a backup in `~/.claude/blossom-theme/backups/` first, and it
  records your old values so the uninstaller can put them back.
- `~/.claude/themes/blossom.json`: the Claude Code UI theme.
- `~/.claude/commands/blossom.md`: the `/blossom` command.
- Windows Terminal, only if you say yes. On your profile it sets the
  background image, the colour scheme (a "Blossom" scheme is added), and it
  makes the window **fully opaque**: window opacity goes to 100% and acrylic
  is turned off, because a see-through window washes out the pink. The
  profile's previous values are backed up first, and `/blossom wt off` or the
  uninstaller puts all of them back. The background GIF goes in
  `%LOCALAPPDATA%\claude-statusline\`. The installer generates the GIF in a
  few seconds; it isn't shipped in the zip.

It does not touch your existing `~/.claude/statusline.py`, other status line
themes, or an existing `/sl` command. You can run the installer again at any
time, for example to upgrade.

## Using it

In Claude Code:

```
/blossom              show the current settings
/blossom 12           make the panel 12 rows tall
/blossom full         let the flowers fill the terminal
/blossom auto         back to the default height (8 rows, or 11 on tall terminals)
/blossom wt on        Windows Terminal: pink background + Blossom scheme
/blossom wt off       Windows Terminal: put your profile(s) back as they were
```

`/blossom wt on` changes the Windows Terminal profile you run it from. You can
run it from more than one profile; `/blossom wt off` and the uninstaller put
every one of them back.

Environment variables you can set (for example in the `env` block of
`settings.json`):

| variable | effect |
|---|---|
| `SL_BLOSSOM_HEIGHT` | panel height, overrides `/blossom N` |
| `SL_BLOSSOM_BLEED=0` | keep the art out of the right-hand gutter |
| `SL_BLOSSOM_OPAQUE=1` | always paint the panel's own pink background |
| `STATUSLINE_NO_TRUECOLOR=1` | 256-colour mode |
| `STATUSLINE_RULE_PAD` | right-hand padding of the info row (default 2) |

## Uninstall

```sh
sh ~/.claude/blossom-theme/uninstall.sh
```

If you installed with `CLAUDE_CONFIG_DIR` set, run the `uninstall.sh` inside
that folder instead (`sh "$CLAUDE_CONFIG_DIR/blossom-theme/uninstall.sh"`). It
works on the install it sits in, even if `CLAUDE_CONFIG_DIR` isn't set in your
current shell. You can also run `sh uninstall.sh` from the unzipped folder,
with the same `CLAUDE_CONFIG_DIR` set as when you installed. The uninstaller:

- puts your Windows Terminal profile(s) back and removes the Blossom scheme;
- deletes the generated GIF;
- restores your previous `statusLine`, `theme` and `COLORTERM` settings. If you
  changed any of them yourself after installing, it leaves them alone;
- removes `themes/blossom.json` and `/blossom` (a `themes/blossom.json` you
  already had before installing is kept or put back);
- deletes `~/.claude/blossom-theme/`.

Your settings backups are moved to `~/.claude/blossom-theme-backups-<date>/`,
which you can delete. Restart Claude Code afterwards.

## Troubleshooting

**No flowers, only the old status line.** Restart Claude Code. Then check that
`~/.claude/settings.json` contains a `statusLine` whose command points at
`blossom-theme/statusline.py`. A project's `.claude/settings.json` can override
it.

**The colours look wrong or washed out.** Claude Code isn't in truecolor mode.
Run `export COLORTERM=truecolor` before starting `claude`, or use
`STATUSLINE_NO_TRUECOLOR=1`.

**The flowers look like stripes, or wrap into a mess.** Your font or terminal
treats `▀ ▄` as double width, or adds line spacing. Use a font with block
elements and line spacing 1.0. In iTerm2, turn off "Treat ambiguous-width
characters as double width". If the panel is slightly too wide, set
`SL_BLOSSOM_BLEED=0`.

**The flowers don't move.** The animation needs
`"refreshInterval": 1` in the `statusLine` block (the installer sets it) and a
recent Claude Code.

**Hard to read text outside Windows Terminal.** The `custom:blossom` UI theme
is a dark theme. Give your terminal a dark background (dark pink `#6B0F3A`
matches perfectly), or switch Claude Code's theme back with `/config` (or
reinstall with `--no-ui-theme`).

**"Windows Terminal settings.json not found" / no pink background.**
- The pink background is only for Windows Terminal + WSL. On macOS and Linux
  you get the status line and the UI theme.
- Windows Terminal's settings are found automatically on any drive mounted
  under `/mnt/<letter>` (`/mnt/c`, `/mnt/d`, ...). Only if your Windows drives
  are mounted somewhere else do you need to say where things are:

  ```sh
  export BLOSSOM_WT_SETTINGS="/mnt/d/Users/<you>/AppData/Local/Packages/Microsoft.WindowsTerminal_8wekyb3d8bbwe/LocalState/settings.json"
  export BLOSSOM_GIF_DIR="/mnt/d/Users/<you>/AppData/Local/claude-statusline"
  ```

  `/blossom` runs inside Claude Code, so these must be in Claude Code's
  environment. Put them in your `~/.bashrc` or `~/.zshrc` and restart
  `claude` from a new shell, or add them to the `env` block of
  `~/.claude/settings.json`. Keep them set when you run `uninstall.sh`, too,
  or it can't find Windows Terminal to put your profile back. It then stops
  without changing anything.
- Comments in Windows Terminal's settings.json are fine. Note that writing the
  file removes them; a full copy is kept as
  `settings.json.before-blossom.bak`.
- If the background lands on the wrong profile: it uses the profile you are
  running in (`WT_PROFILE_ID`). If that profile isn't in settings.json, it
  uses your default profile (`defaultProfile`), and failing that the first
  profile. `/blossom wt off` puts every changed profile back.

**"another status line theme's Windows Terminal background is active".**
You have another theme installed directly in `~/.claude` that set its own
background. Switch that theme off first, so blossom's backup records your real
original profile. Then run `/blossom wt on`.

**`/blossom` fails or asks for permission, and your config folder path
contains a space.** The status line still works. Run the controller
directly instead, for example
`sh ~/.claude/blossom-theme/blossomctl.sh "wt off"` (put your own folder in
the path, in quotes).

**`/blossom` says permission denied.** The installed scripts are always written
with Unix line endings and made executable, so this usually means the folder is
on a mount that forbids running programs (`noexec`). Run it by hand instead:
`sh ~/.claude/blossom-theme/blossomctl.sh "wt off"`.

**`sh install.sh` fails with "Syntax error" or "\r: not found".** Something
on the way (a Windows editor, a git checkout with autocrlf, a sync tool)
converted it to Windows line endings.
Either extract the zip again without conversion (plain `unzip`, or
`python3 -m zipfile -e`), or run the Python installer directly, which does
not mind Windows line endings: `python3 setup/install.py` (it takes the same
options as `install.sh`).

**Something else.** Run the status line by hand to see the error:

```sh
echo '{}' | SL_DEBUG=1 python3 ~/.claude/blossom-theme/statusline.py
```

---

The flower, leaf and background art are original pixel art, drawn for this
theme.
