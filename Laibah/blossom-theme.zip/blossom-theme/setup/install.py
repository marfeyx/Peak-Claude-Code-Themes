#!/usr/bin/env python3
"""Installer for the blossom Claude Code status line theme (run via install.sh).

Everything goes into <config dir>/blossom-theme/, where <config dir> is
$CLAUDE_CONFIG_DIR or ~/.claude. Outside that folder it touches only:

  settings.json        statusLine, theme, env.COLORTERM (backed up first)
  themes/blossom.json  the Claude Code UI theme "custom:blossom"
  commands/blossom.md  the /blossom slash command

Re-running it is safe: it upgrades the files and keeps your settings, the
original values recorded on the first install, and the WT backup.
"""
import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

if sys.version_info < (3, 7):
    sys.exit("blossom needs Python 3.7 or newer (this is %d.%d)" % sys.version_info[:2])

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(PKG, "payload")
MARKER = "installed by blossom-theme"
UI_THEME = "custom:blossom"

# Explicit list: nothing else in the zip is ever copied.
FILES = [
    "statusline.py",
    "statusline-theme",
    "sl-blossom-wt.py",
    "wtbg.py",
    "blossomctl.py",
    "blossomctl.sh",
    "uninstall.py",
    "uninstall.sh",
    "statuslines/blossom.py",
    "statuslines/blossompal.py",
    "statuslines/blossomflower.py",
    "statuslines/blossomleaf.py",
    "statuslines/blossomgif.py",
    "statuslines/gifwriter.py",
    "statuslines/common.py",
    "statuslines/agentcount.py",
    "themes/blossom.json",
    "commands/blossom.md",
]
EXECUTABLE = {"statusline.py", "sl-blossom-wt.py", "wtbg.py", "blossomctl.py",
              "blossomctl.sh", "uninstall.py", "uninstall.sh"}


def say(msg=""):
    print(msg, flush=True)


def stamp():
    return time.strftime("%Y%m%d-%H%M%S")


def read_text(path):
    with open(path, encoding="utf-8-sig") as fh:
        return fh.read()


def write_atomic(path, text, mode=None):
    path = os.path.realpath(path)            # keep a symlinked file a symlink
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = "%s.blossom-tmp.%d" % (path, os.getpid())
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    if mode is None and os.path.exists(path):
        mode = os.stat(path).st_mode & 0o7777    # keep e.g. a 0600 settings.json 0600
    if mode is not None:
        os.chmod(tmp, mode)
    os.replace(tmp, path)


def load_settings(path):
    """settings.json as a dict ({} if missing or empty). Exits if unreadable."""
    if not os.path.exists(path):
        return {}, False
    try:
        text = read_text(path)
    except (OSError, UnicodeDecodeError) as exc:
        sys.exit("cannot read %s: %s\nNothing was changed." % (path, exc))
    if not text.strip():
        return {}, True
    try:
        data = json.loads(text)
    except ValueError as exc:
        sys.exit("%s is not valid JSON (%s).\nFix it (or move it away) and run "
                 "the installer again. Nothing was changed." % (path, exc))
    if not isinstance(data, dict):
        sys.exit("%s does not contain a JSON object. Nothing was changed." % path)
    return data, True


def dump_settings(data):
    return json.dumps(data, indent=2, ensure_ascii=False) + "\n"


def python_ok(cmd):
    """True when `cmd` runs and is Python 3.7 or newer."""
    try:
        return subprocess.run(
            [cmd, "-c", "import sys; sys.exit(sys.version_info < (3, 7))"],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, timeout=20).returncode == 0
    except Exception:
        return False


def python_command():
    """How the status line should call Python. Prefer plain `python3` on PATH
    (survives interpreter upgrades) when it really is Python 3.7+, else the
    interpreter running this."""
    py3 = shutil.which("python3")
    if os.name != "nt" and py3 and python_ok(py3):
        return "python3", py3
    exe = sys.executable or "python3"
    return exe, exe


def quote(path):
    if os.name == "nt":
        return '"%s"' % path.replace("\\", "/")
    return shlex.quote(path)


def ask(question, default=True):
    """Yes/no on a terminal; None when nobody can answer (stdin is not a tty)."""
    if not sys.stdin.isatty():
        return None
    hint = "[Y/n]" if default else "[y/N]"
    try:
        answer = input("%s %s " % (question, hint)).strip().lower()
    except EOFError:
        return default
    return default if not answer else answer.startswith("y")


def main():
    ap = argparse.ArgumentParser(prog="install.sh", description=__doc__.split("\n")[0])
    ap.add_argument("--yes", "-y", action="store_true",
                    help="answer yes to every question (non-interactive)")
    wt = ap.add_mutually_exclusive_group()
    wt.add_argument("--wt", action="store_true",
                    help="apply the Windows Terminal pink background without asking")
    wt.add_argument("--no-wt", action="store_true",
                    help="never touch Windows Terminal")
    ap.add_argument("--no-ui-theme", action="store_true",
                    help="leave Claude Code's own UI theme alone")
    ap.add_argument("--height", metavar="ROWS|full|auto",
                    help="panel height (default: auto)")
    args = ap.parse_args()

    if not os.path.isdir(SRC):
        sys.exit("payload/ not found next to install.sh - unzip the whole archive first")

    cfg = os.path.abspath(os.path.expanduser(
        os.environ.get("CLAUDE_CONFIG_DIR") or os.path.join("~", ".claude")))
    dest = os.path.join(cfg, "blossom-theme")
    settings_file = os.path.join(cfg, "settings.json")
    backups = os.path.join(dest, "backups")

    say("Installing the blossom status line into %s" % dest)
    if " " in dest:
        say("  note: the path contains a space. The status line is fine; if /blossom\n"
            "  fails or asks for permission, run %s directly."
            % os.path.join(dest, "blossomctl.sh"))

    # 1. settings.json must be readable BEFORE anything is written.
    settings, settings_existed = load_settings(settings_file)

    # 2. the files
    created_dirs = [d for d in (os.path.join(cfg, "themes"), os.path.join(cfg, "commands"))
                    if not os.path.isdir(d)]
    os.makedirs(backups, exist_ok=True)
    py_cmd, py_abs = python_command()
    dest_fwd = dest.replace("\\", "/")
    ctl = dest_fwd + "/blossomctl.sh"
    # The command line in commands/blossom.md: quoted only when it has to be,
    # so the common case stays a plain path that the allowed-tools rule matches.
    subst = {"__PYTHON__": py_abs.replace("\\", "/"),
             "__BLOSSOM_CTL__": ('"%s"' % ctl) if " " in ctl else ctl,
             "__BLOSSOM_DIR__": dest_fwd}
    for rel in FILES:
        text = read_text(os.path.join(SRC, *rel.split("/")))
        text = text.replace("\r\n", "\n")
        if rel in ("blossomctl.sh", "commands/blossom.md"):
            for k, v in subst.items():
                text = text.replace(k, v)
        mode = 0o755 if rel in EXECUTABLE else 0o644
        write_atomic(os.path.join(dest, *rel.split("/")), text, mode)
    shutil.rmtree(os.path.join(dest, "statuslines", "__pycache__"), ignore_errors=True)
    say("  copied %d files" % len(FILES))

    if args.height:
        h = args.height.strip().lower()
        if h in ("full", "auto") or (h.isdigit() and 1 <= int(h) <= 99):
            write_atomic(os.path.join(dest, "statusline-blossom-height"), h + "\n", 0o644)
        else:
            say("  ignoring --height %s (use a row count, full or auto)" % args.height)

    # 3. remember what was there before (first install only)
    state_file = os.path.join(dest, "install-state.json")
    try:
        with open(state_file, encoding="utf-8") as fh:
            state = json.load(fh)
        first = False
    except (OSError, ValueError):
        state, first = {}, True

    our_command = "%s %s" % (py_cmd if py_cmd == "python3" else quote(py_cmd),
                             quote(os.path.join(dest, "statusline.py")))
    themes_dir = os.path.join(cfg, "themes")
    cc_theme = os.path.join(themes_dir, "blossom.json")
    if first:
        old_sl = settings.get("statusLine")
        ours = isinstance(old_sl, dict) and os.path.join(dest, "statusline.py") in str(old_sl.get("command", ""))
        state = {
            "version": 1,
            "installed": stamp(),
            "settings_existed": settings_existed,
            "had_statusLine": "statusLine" in settings and not ours,
            "statusLine": None if ours else old_sl,
            # recorded as found, even if it already was custom:blossom, so the
            # uninstaller puts back exactly what was there
            "had_theme": "theme" in settings,
            "theme": settings.get("theme"),
            # likewise: a themes/blossom.json that was already there is kept
            "had_theme_file": os.path.exists(cc_theme),
            "set_theme": False,
            "added_colorterm": False,
            "created_env": False,
            "themes_backup": None,
            "command_backup": None,
            "created_dirs": created_dirs,
        }
    state["our_command"] = our_command

    # 4. Claude Code UI theme file
    shipped_theme = read_text(os.path.join(SRC, "themes", "blossom.json")).replace("\r\n", "\n")
    if os.path.exists(cc_theme):
        try:
            current = read_text(cc_theme).replace("\r\n", "\n")
        except (OSError, UnicodeDecodeError):
            current = None
        if current != shipped_theme and not state.get("themes_backup"):
            b = os.path.join(backups, "themes-blossom.json.%s" % stamp())
            shutil.copy2(cc_theme, b)
            state["themes_backup"] = b
            say("  backed up your existing themes/blossom.json to %s" % b)
    write_atomic(cc_theme, shipped_theme, 0o644)

    # 5. the /blossom slash command
    cmd_file = os.path.join(cfg, "commands", "blossom.md")
    rendered = read_text(os.path.join(dest, "commands", "blossom.md"))
    if os.path.exists(cmd_file):
        try:
            current = read_text(cmd_file)
        except (OSError, UnicodeDecodeError):
            current = ""
        if MARKER not in current and not state.get("command_backup"):
            b = os.path.join(backups, "commands-blossom.md.%s" % stamp())
            shutil.copy2(cmd_file, b)
            state["command_backup"] = b
            say("  backed up your existing commands/blossom.md to %s" % b)
    write_atomic(cmd_file, rendered, 0o644)

    # 6. settings.json
    before = dump_settings(settings)
    settings["statusLine"] = {"type": "command", "command": our_command,
                              "refreshInterval": 1}
    if not args.no_ui_theme:
        if settings.get("theme") != UI_THEME:
            settings["theme"] = UI_THEME
        state["set_theme"] = True
    env = settings.get("env")
    if env is None:
        env = settings["env"] = {}
        state["created_env"] = True
    if isinstance(env, dict) and "COLORTERM" not in env:
        env["COLORTERM"] = "truecolor"
        state["added_colorterm"] = True
    after = dump_settings(settings)
    if after != before:
        if settings_existed:
            b = os.path.join(backups, "settings.json.%s" % stamp())
            n = 1
            while os.path.exists(b):             # two installs in one second
                b = os.path.join(backups, "settings.json.%s.%d" % (stamp(), n))
                n += 1
            shutil.copy2(settings_file, b)
            state.setdefault("settings_backup", b)   # uninstall restores these bytes
            say("  backed up settings.json to %s" % b)
        write_atomic(settings_file, after)
        say("  settings.json: statusLine -> blossom%s" %
            ("" if args.no_ui_theme else ", theme -> custom:blossom"))
    else:
        say("  settings.json already up to date")
    write_atomic(state_file, json.dumps(state, indent=2) + "\n", 0o644)

    # 7. smoke test
    env_run = dict(os.environ, COLUMNS="80", LINES="30", SL_BLOSSOM_OPAQUE="1")
    try:
        p = subprocess.run([sys.executable, os.path.join(dest, "statusline.py")],
                           input=b"{}", stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           env=env_run, timeout=30)
        out = p.stdout.decode("utf-8", "replace")
        ok = p.returncode == 0 and out.strip() and "failed:" not in out
    except Exception as exc:
        ok, out = False, str(exc)
    if ok:
        say("  status line test render: OK (%d rows)" % len(out.rstrip("\n").split("\n")))
    else:
        say("  WARNING: the status line test render failed:\n%s" % out[-500:])

    # 8. Windows Terminal (optional)
    in_wt = bool(os.environ.get("WT_SESSION") or os.environ.get("BLOSSOM_WT_SETTINGS"))
    say("")
    if args.no_wt:
        say("Windows Terminal: skipped (--no-wt).")
    elif not in_wt and not args.wt:
        say("Windows Terminal: not detected, skipping the pink window background.\n"
            "  The status line works without it. In Windows Terminal, run /blossom wt on.")
    else:
        foreign = os.path.join(cfg, "statusline-wt-backup.json")
        if os.path.exists(foreign) and not os.path.exists(
                os.path.join(dest, "statusline-wt-backup.json")):
            say("Windows Terminal: another status line theme currently owns the WT\n"
                "  background (%s exists). Switch that theme off first,\n"
                "  then run /blossom wt on." % foreign)
        else:
            yes = True if (args.wt or args.yes) else ask(
                "Windows Terminal detected. Set this profile's background to the\n"
                "animated pink sakura and its colour scheme to Blossom? This also\n"
                "makes the window fully opaque (opacity 100%, acrylic off). Your\n"
                "profile is backed up, and `/blossom wt off` or uninstall.sh puts\n"
                "all of it back.")
            if yes is None:
                say("Windows Terminal: detected, but left alone (no terminal to ask on).\n"
                    "  Re-run with --wt, or run /blossom wt on inside Claude Code.")
            elif yes:
                p = subprocess.run([sys.executable, os.path.join(dest, "blossomctl.py"),
                                    "wt", "on"],
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   universal_newlines=True)
                say("Windows Terminal: " + p.stdout.strip().replace("\n", "\n  "))
            else:
                say("Windows Terminal: left alone. Run /blossom wt on any time.")

    say("")
    say("Done. Restart Claude Code to see the blossom status line.")
    say("  /blossom <rows|full|auto>  panel height     /blossom wt on|off  WT background")
    if not os.environ.get("COLORTERM"):
        say("  Tip: start claude with COLORTERM=truecolor set (e.g. add\n"
            "  `export COLORTERM=truecolor` to your shell rc) for exact colours.")
    say("  Uninstall: %s" % os.path.join(dest, "uninstall.sh"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
