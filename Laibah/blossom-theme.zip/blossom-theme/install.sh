#!/bin/sh
# Install the blossom status line theme for Claude Code.
#   sh install.sh [--yes] [--wt | --no-wt] [--no-ui-theme] [--height ROWS|full|auto]
# Installs into ${CLAUDE_CONFIG_DIR:-$HOME/.claude}/blossom-theme/.
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
# First of python3 / python / py -3 that really is Python 3.7+ (skips the
# Microsoft Store python3 stub on Windows and a Python 2 `python`).
PY= PYARG=
for c in python3 python py; do
    command -v "$c" >/dev/null 2>&1 || continue
    a=; [ "$c" = py ] && a=-3
    if "$c" ${a:+"$a"} -c 'import sys; sys.exit(sys.version_info < (3, 7))' >/dev/null 2>&1; then
        PY=$c PYARG=$a; break
    fi
done
[ -n "$PY" ] || { echo "Python 3.7 or newer not found: install it first (see README.md)" >&2; exit 1; }
exec "$PY" ${PYARG:+"$PYARG"} "$here/setup/install.py" "$@"
